/**
 * TypeScript models for the Issue Service (IssueResponse in the backend).
 *
 * The case study's "Object Value Mapping" gives each value a number (Status 1 = To-Do, 2 = Development,
 * 3 = Testing, 4 = Completed; Priority 1 = LOW, 2 = MEDIUM, 3 = HIGH; Type 1 = BUG, 2 = TASK, 3 = STORY).
 * The backend sends the NAMES ("TO_DO", "HIGH" ...), so the app uses the names; the lists below keep the
 * case study's order, so position + 1 is the case study's number.
 */

/** Where an issue is in its life cycle - one board column each. */
export type IssueStatus = 'TO_DO' | 'DEVELOPMENT' | 'TESTING' | 'COMPLETED';

/** How urgent an issue is. */
export type Priority = 'LOW' | 'MEDIUM' | 'HIGH';

/** What kind of work an issue is. */
export type IssueType = 'BUG' | 'TASK' | 'STORY';

/** Board columns, left to right. */
export const ISSUE_STATUSES: IssueStatus[] = ['TO_DO', 'DEVELOPMENT', 'TESTING', 'COMPLETED'];

/** Priorities, lowest first. */
export const PRIORITIES: Priority[] = ['LOW', 'MEDIUM', 'HIGH'];

/** Issue types. */
export const ISSUE_TYPES: IssueType[] = ['BUG', 'TASK', 'STORY'];

/** Text shown for each status (column headings, drop-downs). */
export const STATUS_LABELS: Record<IssueStatus, string> = {
  TO_DO: 'To Do',
  DEVELOPMENT: 'Development',
  TESTING: 'Testing',
  COMPLETED: 'Completed',
};

/** Text shown for each priority. */
export const PRIORITY_LABELS: Record<Priority, string> = {
  LOW: 'Low',
  MEDIUM: 'Medium',
  HIGH: 'High',
};

/** Text shown for each type. */
export const TYPE_LABELS: Record<IssueType, string> = {
  BUG: 'Bug',
  TASK: 'Task',
  STORY: 'Story',
};

/** An issue as the backend returns it. */
export interface Issue {
  issueId: number;
  summary: string;              // the title of the issue
  description: string | null;
  projectId: number;
  assigneeId: number;           // userId of the Assignee working on it
  createdBy: number;            // userId of the Project Owner who created it
  priority: Priority;
  status: IssueStatus;
  type: IssueType;
  sprint: number | null;
  storyPoint: number;
  tags: string | null;          // comma-separated, e.g. "backend,login"
  createdOn: string;            // "yyyy-MM-dd"
  lastUpdated: string;          // "yyyy-MM-ddTHH:mm:ss"
}

/** Type guard: is this text one of the priorities? (drop-down values are plain text) */
export function isPriority(value: string): value is Priority {
  return PRIORITIES.includes(value as Priority);
}

/** Type guard: is this text one of the statuses? */
export function isIssueStatus(value: string): value is IssueStatus {
  return ISSUE_STATUSES.includes(value as IssueStatus);
}

/** Type guard: is this text one of the issue types? */
export function isIssueType(value: string): value is IssueType {
  return ISSUE_TYPES.includes(value as IssueType);
}

/** Body of POST /api/issues (create). createdBy is the logged-in Project Owner. */
export interface CreateIssueRequest {
  summary: string;
  description: string | null;
  projectId: number;
  assigneeId: number;
  createdBy: number;
  priority: Priority;
  status: IssueStatus;
  type: IssueType;
  sprint: number;
  storyPoint: number;
  tags: string | null;          // "delivery,feature"
}

/**
 * Body of PUT /api/issues/{id}. Every field is optional: the backend only changes the fields that are
 * sent (a "partial update"), so the Assignee can send just { status } (Milestone 6).
 * An empty text ("") clears the description or the tags.
 */
export interface UpdateIssueRequest {
  summary?: string;
  description?: string;
  projectId?: number;
  assigneeId?: number;
  priority?: Priority;
  status?: IssueStatus;
  type?: IssueType;
  sprint?: number;
  storyPoint?: number;
  tags?: string;
}

/** Answer of a successful create or update: a message and the saved issue. */
export interface IssueSavedResponse {
  message: string;
  issue: Issue;
}
