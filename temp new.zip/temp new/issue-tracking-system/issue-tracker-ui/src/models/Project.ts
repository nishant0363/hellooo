/**
 * TypeScript models for the Project Service (ProjectResponse / ProjectRequest in the backend).
 * Dates travel as text in the ISO format "yyyy-MM-dd", e.g. "2026-09-01".
 */

/** A project as the backend returns it. */
export interface Project {
  projectId: number;
  projectName: string;
  projectOwnerId: number;   // userId of the Project Owner
  startDate: string;        // "yyyy-MM-dd"
  endDate: string | null;   // optional in the backend
}

/** Body of POST /api/projects (create). */
export interface ProjectRequest {
  projectName: string;
  projectOwnerId: number;
  startDate: string;        // "yyyy-MM-dd"
  endDate: string | null;
}

/** Answer of a successful create: a message and the saved project (with its new id). */
export interface ProjectSavedResponse {
  message: string;
  project: Project;
}
