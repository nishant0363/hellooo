/**
 * The JSON body every backend service sends when something goes wrong
 * (the ErrorResponse record in each Spring Boot service's GlobalExceptionHandler), for example:
 *   { "status": 409, "error": "Conflict", "message": "A user with email 'a@b.com' already exists", ... }
 * Fields are optional (?) because errors produced by the API Gateway itself may not include all of them.
 */
export interface ApiErrorResponse {
  timestamp?: string;
  status?: number;
  error?: string;
  message?: string;
  path?: string;
  fieldErrors?: Record<string, string>;   // only for 400 validation errors: { "email": "Email is required" }
}
