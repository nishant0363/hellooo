import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Avatar } from '../common/Avatar';
import { PriorityBadge } from '../common/PriorityBadge';
import { TagChips } from '../common/TagChips';
import { STATUS_LABELS, TYPE_LABELS } from '../../models/Issue';
import type { Issue } from '../../models/Issue';
import type { User } from '../../models/User';
import { formatDate, formatDateTime } from '../../utils/dateUtils';

/** Props of IssueDetailsView. */
interface IssueDetailsViewProps {
  issue: Issue;
  projectName: string;
  assignee: User | undefined;
  breadcrumbLabel: string;   // first breadcrumb entry, e.g. "Project Board"
  breadcrumbTo: string;      // where it links to
  actions?: ReactNode;       // right-hand buttons: "Edit Issue" (owner) or the status form (assignee)
}

/**
 * Read-only view of one issue, laid out like the case study's Issue Details screen: breadcrumb, title,
 * description, a "Details" list on the left and status / assignee / dates on the right.
 * Shared by the Project Owner (Milestone 5) and the Assignee (Milestone 6); each passes its own actions.
 */
export function IssueDetailsView({
  issue,
  projectName,
  assignee,
  breadcrumbLabel,
  breadcrumbTo,
  actions,
}: IssueDetailsViewProps) {
  /** Name to show; a placeholder if the user could not be found. */
  const assigneeName = assignee?.name ?? `User #${issue.assigneeId}`;

  return (
    <>
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb small mb-2">
          <li className="breadcrumb-item">
            <Link to={breadcrumbTo}>{breadcrumbLabel}</Link>
          </li>
          <li className="breadcrumb-item active" aria-current="page">
            Issue Details
          </li>
        </ol>
      </nav>

      <h1 className="issue-detail-title">
        <span className="text-muted fs-6 me-2">#{issue.issueId}</span>
        {issue.summary}
      </h1>

      <div className="row g-4">
        <div className="col-lg-8">
          <div className="small fw-semibold text-muted">Description :</div>
          <p className="mb-3">
            {issue.description ?? <span className="text-muted fst-italic">No description</span>}
          </p>

          <h2 className="h6 fw-bold border-top pt-3">Details</h2>
          <dl className="row small mb-0">
            <dt className="col-sm-3">Project</dt>
            <dd className="col-sm-9">{projectName}</dd>
            <dt className="col-sm-3">Type</dt>
            <dd className="col-sm-9">{TYPE_LABELS[issue.type]}</dd>
            <dt className="col-sm-3">Priority</dt>
            <dd className="col-sm-9">
              <PriorityBadge priority={issue.priority} />
            </dd>
            <dt className="col-sm-3">Sprint</dt>
            <dd className="col-sm-9">{issue.sprint ?? '-'}</dd>
            <dt className="col-sm-3">Story Points</dt>
            <dd className="col-sm-9">{issue.storyPoint}</dd>
            <dt className="col-sm-3">Tags</dt>
            <dd className="col-sm-9">
              <TagChips tags={issue.tags} />
            </dd>
          </dl>
        </div>

        <div className="col-lg-4">
          {actions && <div className="mb-3">{actions}</div>}
          <div className="card shadow-sm">
            <div className="card-body small d-flex flex-column gap-2">
              <div>
                <span className="fw-semibold me-2">Status:</span>
                <span className={`badge status-badge status-${issue.status}`}>{STATUS_LABELS[issue.status]}</span>
              </div>
              <div className="d-flex align-items-center gap-2">
                <span className="fw-semibold">Assignee:</span>
                <Avatar name={assigneeName} imageUrl={assignee?.profile ?? null} size={24} />
                <span>{assigneeName}</span>
                {assignee && <span className="text-muted">@{assignee.username}</span>}
              </div>
              <div>
                <span className="fw-semibold me-2">Created On:</span>
                {formatDate(issue.createdOn)}
              </div>
              <div>
                <span className="fw-semibold me-2">Last Updated:</span>
                {formatDateTime(issue.lastUpdated)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
