/** Props of ErrorAlert. */
interface ErrorAlertProps {
  message: string;
  onRetry?: () => void;   // when given, a "Try again" button is shown
}

/** Red Bootstrap alert for a failed request, optionally with a "Try again" button. */
export function ErrorAlert({ message, onRetry }: ErrorAlertProps) {
  return (
    <div className="alert alert-danger d-flex justify-content-between align-items-center gap-3" role="alert">
      <span>
        <i className="bi bi-exclamation-triangle me-2" aria-hidden="true"></i>
        {message}
      </span>
      {onRetry && (
        <button type="button" className="btn btn-sm btn-outline-danger text-nowrap" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}
