import { useState } from 'react';

/** Props of Avatar. */
interface AvatarProps {
  name: string;               // used for the alt text and the initials
  imageUrl: string | null;    // profile photo URL (may be missing)
  size?: number;              // width and height in pixels
}

/** "Priya Sharma" -> "PS", "rahul" -> "R". */
function getInitials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((word) => word.charAt(0).toUpperCase())
    .join('');
}

/**
 * Round profile picture. If there is no URL, or the image fails to load (broken link, no internet),
 * it shows the person's initials instead, so the layout never shows a broken-image icon.
 */
export function Avatar({ name, imageUrl, size = 40 }: AvatarProps) {
  /** The URL that failed to load. Remembering the URL (not just true/false) means a NEW URL is tried again. */
  const [failedUrl, setFailedUrl] = useState<string | null>(null);

  const showImage = imageUrl !== null && imageUrl !== '' && imageUrl !== failedUrl;

  if (!showImage) {
    return (
      <span
        className="avatar avatar-initials"
        style={{ width: size, height: size, fontSize: size * 0.4 }}
        role="img"
        aria-label={name}
      >
        {getInitials(name) || '?'}
      </span>
    );
  }

  return (
    <img
      src={imageUrl}
      alt={name}
      width={size}
      height={size}
      className="avatar"
      onError={() => setFailedUrl(imageUrl)}
    />
  );
}
