import { parseTags } from '../../utils/tagUtils';

/** Props of TagChips. */
interface TagChipsProps {
  tags: string | null;   // as stored by the backend: "delivery,feature"
}

/** Shows an issue's tags as small green chips: #delivery #feature (or "-" when there are none). */
export function TagChips({ tags }: TagChipsProps) {
  const tagList = parseTags(tags);
  if (tagList.length === 0) {
    return <span className="text-muted">-</span>;
  }
  return (
    <span className="d-inline-flex flex-wrap gap-1">
      {tagList.map((tag) => (
        <span key={tag} className="badge rounded-pill text-bg-success fw-normal">
          #{tag}
        </span>
      ))}
    </span>
  );
}
