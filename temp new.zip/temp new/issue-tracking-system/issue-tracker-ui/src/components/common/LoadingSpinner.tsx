/** Props of LoadingSpinner. */
interface LoadingSpinnerProps {
  label?: string;   // text next to the spinner, also read by screen readers
}

/** Centred Bootstrap spinner shown while data is being loaded from the backend. */
export function LoadingSpinner({ label = 'Loading...' }: LoadingSpinnerProps) {
  return (
    <div className="d-flex justify-content-center align-items-center gap-2 py-5 text-muted" role="status">
      <span className="spinner-border spinner-border-sm" aria-hidden="true"></span>
      <span>{label}</span>
    </div>
  );
}
