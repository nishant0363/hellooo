import { IssueCard } from './IssueCard';
import { STATUS_LABELS } from '../../models/Issue';
import type { Issue, IssueStatus } from '../../models/Issue';
import type { User } from '../../models/User';

/** Icon of each column heading (Bootstrap Icons). */
const STATUS_ICONS: Record<IssueStatus, string> = {
  TO_DO: 'bi-list-task',
  DEVELOPMENT: 'bi-code-slash',
  TESTING: 'bi-ui-checks',
  COMPLETED: 'bi-check2-square',
};

/** Props of IssueColumn. */
interface IssueColumnProps {
  status: IssueStatus;
  issues: Issue[];               // only the issues with this status
  usersById: Map<number, User>;  // to find each card's assignee
  getIssueLink?: (issue: Issue) => string;   // where a click on a card goes
}

/**
 * One column of the board (e.g. "TO DO") with its issue count and cards.
 * The class "status-TO_DO" etc. sets the column's colour in index.css.
 */
export function IssueColumn({ status, issues, usersById, getIssueLink }: IssueColumnProps) {
  return (
    <section className={`issue-column status-${status}`} aria-label={`${STATUS_LABELS[status]} issues`}>
      <h3 className="issue-column-header">
        <i className={`bi ${STATUS_ICONS[status]} me-2`} aria-hidden="true"></i>
        {STATUS_LABELS[status].toUpperCase()}
        <span className="badge rounded-pill status-badge ms-2">{issues.length}</span>
      </h3>
      <div className="issue-column-body">
        {issues.length === 0 ? (
          <p className="text-muted small text-center my-3">No issues</p>
        ) : (
          issues.map((issue) => (
            <IssueCard
              key={issue.issueId}
              issue={issue}
              assignee={usersById.get(issue.assigneeId)}
              linkTo={getIssueLink?.(issue)}
            />
          ))
        )}
      </div>
    </section>
  );
}
