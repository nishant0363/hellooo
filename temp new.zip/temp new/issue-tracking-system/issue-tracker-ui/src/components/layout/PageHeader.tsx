import { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';

/** "Good morning" before 12:00, "Good afternoon" before 17:00, otherwise "Good evening" (the user's own clock). */
function getGreeting(hour: number): string {
  if (hour < 12) {
    return 'Good morning';
  }
  return hour < 17 ? 'Good afternoon' : 'Good evening';
}

/** Props of PageHeader. Both are optional: pages without a search box simply leave them out. */
interface PageHeaderProps {
  searchText?: string;
  onSearchChange?: (text: string) => void;
}

/**
 * Yellow bar at the top of every logged-in page: the search box on the left (only on the dashboards,
 * when the page passes onSearchChange) and a greeting with the user's first name on the right (the app name is in the sidebar).
 * The search box is controlled: its text lives in the dashboard page's state.
 */
export function PageHeader({ searchText = '', onSearchChange }: PageHeaderProps) {
  const { user } = useAuth();
  /** First word of the logged-in user's name, for the greeting. */
  const firstName = user?.name.trim().split(/\s+/)[0] ?? '';
  /** Worked out once when the header appears (reading the clock during every render would be impure). */
  const [greeting] = useState(() => getGreeting(new Date().getHours()));

  return (
    <header className="brand-bar d-flex align-items-center justify-content-between gap-3 px-3 py-2">
      {onSearchChange ? (
        <div className="input-group input-group-sm header-search" role="search">
          <input
            type="search"
            className="form-control"
            placeholder="Search issue by summary or description"
            aria-label="Search issues by summary or description (regular expressions allowed)"
            value={searchText}
            onChange={(event) => onSearchChange(event.target.value)}
          />
          <span className="input-group-text">
            <i className="bi bi-search" aria-hidden="true"></i>
          </span>
        </div>
      ) : (
        <span></span>
      )}
      <span className="header-greeting text-nowrap">
        {greeting}, {firstName}
      </span>
    </header>
  );
}
