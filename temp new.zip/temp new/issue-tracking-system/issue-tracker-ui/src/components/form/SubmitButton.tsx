/** Props of SubmitButton. */
interface SubmitButtonProps {
  label: string;          // normal text, e.g. "Login"
  loadingLabel: string;   // text while the request is running, e.g. "Logging in..."
  loading: boolean;       // true while the API request is in progress
  disabled: boolean;      // true while the form is invalid
}

/**
 * Reusable yellow submit button used by every form.
 * It is disabled when the form is invalid AND while the request is running, so the user cannot
 * send the same form twice by double-clicking. While loading it shows a small spinner.
 */
export function SubmitButton({ label, loadingLabel, loading, disabled }: SubmitButtonProps) {
  return (
    <button type="submit" className="btn btn-warning px-4" disabled={disabled || loading}>
      {loading ? (
        <>
          <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
          {loadingLabel}
        </>
      ) : (
        label
      )}
    </button>
  );
}
