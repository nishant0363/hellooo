import type { ChangeEvent, FocusEvent, HTMLInputTypeAttribute } from 'react';

/** Props of TextField. The "?" marks optional props. */
interface TextFieldProps {
  label: string;
  name: string;                 // must match the field's key in the form values
  value: string;
  onChange: (event: ChangeEvent<HTMLInputElement>) => void;
  onBlur: (event: FocusEvent<HTMLInputElement>) => void;
  error?: string;               // message to show under the field (undefined = no message)
  type?: HTMLInputTypeAttribute;   // text, email, password, url, number, date ...
  placeholder?: string;
  autoComplete?: string;        // helps the browser offer saved emails/passwords
  disabled?: boolean;
  min?: string;                 // lowest allowed value (e.g. the earliest date the date picker offers)
  inputMode?: 'text' | 'numeric';  // "numeric" shows a number keypad on phones
  helpText?: string;            // grey hint under the field, shown while there is no error
}

/**
 * Reusable labelled input with a Bootstrap validation message.
 * When there is an error, "is-invalid" turns the border red and Bootstrap shows the
 * "invalid-feedback" text under the input.
 */
export function TextField({
  label,
  name,
  value,
  onChange,
  onBlur,
  error,
  type = 'text',
  placeholder,
  autoComplete,
  disabled = false,
  min,
  inputMode,
  helpText,
}: TextFieldProps) {
  /** id of the message element, so screen readers read the message together with the input. */
  const errorId = `${name}-error`;
  /** id of the hint element. */
  const helpId = `${name}-help`;

  return (
    <div className="mb-3">
      <label htmlFor={name} className="form-label">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        value={value}
        placeholder={placeholder}
        autoComplete={autoComplete}
        disabled={disabled}
        min={min}
        inputMode={inputMode}
        className={`form-control ${error ? 'is-invalid' : ''}`}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : helpText ? helpId : undefined}
        onChange={onChange}
        onBlur={onBlur}
      />
      {error && (
        <div id={errorId} className="invalid-feedback">
          {error}
        </div>
      )}
      {!error && helpText && (
        <div id={helpId} className="form-text">
          {helpText}
        </div>
      )}
    </div>
  );
}
