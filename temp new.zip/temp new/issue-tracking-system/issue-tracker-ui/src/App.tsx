import { Navigate, Route, Routes } from 'react-router-dom';
import AssigneeDashboardPage from './pages/assignee/AssigneeDashboardPage';
import AssigneeIssueDetailsPage from './pages/assignee/AssigneeIssueDetailsPage';
import AssigneeLayout from './pages/assignee/AssigneeLayout';
import LoginPage from './pages/auth/LoginPage';
import SignupPage from './pages/auth/SignupPage';
import NotFoundPage from './pages/NotFoundPage';
import CreateIssuePage from './pages/owner/CreateIssuePage';
import CreateProjectPage from './pages/owner/CreateProjectPage';
import EditIssuePage from './pages/owner/EditIssuePage';
import IssueDetailsPage from './pages/owner/IssueDetailsPage';
import OwnerDashboardPage from './pages/owner/OwnerDashboardPage';
import OwnerLayout from './pages/owner/OwnerLayout';
import { GuestRoute } from './routes/GuestRoute';
import { PATHS } from './routes/paths';
import { ProtectedRoute } from './routes/ProtectedRoute';

/**
 * The route table: which page is shown for which URL.
 *
 * Routes without a path (element={<GuestRoute />} ...) are "layout routes": they wrap a group of pages
 * and decide, before any of them is shown, whether the visitor may see it (see the routes folder).
 */
export default function App() {
  return (
    <Routes>
      {/* The start page is the Login page (GuestRoute forwards logged-in users to their dashboard) */}
      <Route path="/" element={<Navigate to={PATHS.LOGIN} replace />} />

      {/* Only for visitors who are NOT logged in */}
      <Route element={<GuestRoute />}>
        <Route path={PATHS.LOGIN} element={<LoginPage />} />
        <Route path={PATHS.SIGNUP} element={<SignupPage />} />
      </Route>

      {/* Only for logged-in Project Owners. OwnerLayout adds the sidebar and loads the owner's data. */}
      <Route element={<ProtectedRoute allowedRole="PROJECT_OWNER" />}>
        <Route element={<OwnerLayout />}>
          <Route path={PATHS.OWNER_DASHBOARD} element={<OwnerDashboardPage />} />
          <Route path={PATHS.CREATE_PROJECT} element={<CreateProjectPage />} />
          <Route path={PATHS.CREATE_ISSUE} element={<CreateIssuePage />} />
          <Route path={PATHS.OWNER_ISSUE_DETAILS} element={<IssueDetailsPage />} />
          <Route path={PATHS.EDIT_ISSUE} element={<EditIssuePage />} />
        </Route>
      </Route>

      {/* Only for logged-in Assignees. AssigneeLayout adds the sidebar and loads the Assignee's issues. */}
      <Route element={<ProtectedRoute allowedRole="ASSIGNEE" />}>
        <Route element={<AssigneeLayout />}>
          <Route path={PATHS.ASSIGNEE_DASHBOARD} element={<AssigneeDashboardPage />} />
          <Route path={PATHS.ASSIGNEE_ISSUE_DETAILS} element={<AssigneeIssueDetailsPage />} />
        </Route>
      </Route>

      {/* Any other URL */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
