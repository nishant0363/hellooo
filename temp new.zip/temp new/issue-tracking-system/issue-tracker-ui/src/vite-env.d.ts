/// <reference types="vite/client" />

/**
 * Types for the variables in the .env file, so `import.meta.env.VITE_API_BASE_URL` is a known string
 * instead of an untyped value. Vite only exposes variables whose names start with VITE_.
 */
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
