/**
 * Data passed from one page to another with React Router's navigate(path, { state }).
 * Here: after a successful sign-up the Signup page opens the Login page and passes the success
 * message and the new email (so the email box is already filled in).
 */
export interface SignupSuccessState {
  signupMessage: string;
  email: string;
}

/**
 * React Router gives the state to the next page without a type, because ANY value could have been
 * passed. This type guard checks it really is a SignupSuccessState before the page uses it.
 */
export function isSignupSuccessState(state: unknown): state is SignupSuccessState {
  return (
    typeof state === 'object' &&
    state !== null &&
    'signupMessage' in state &&
    'email' in state &&
    typeof state.signupMessage === 'string' &&
    typeof state.email === 'string'
  );
}

/**
 * A one-time success message for the next page, e.g. after creating a project the dashboard shows
 * "Project "Payments Gateway" was created successfully." (see components/common/FlashMessage.tsx).
 */
export interface FlashMessageState {
  flashMessage: string;
}

/** Type guard: does the router state carry a flash message? */
export function isFlashMessageState(state: unknown): state is FlashMessageState {
  return (
    typeof state === 'object' &&
    state !== null &&
    'flashMessage' in state &&
    typeof state.flashMessage === 'string'
  );
}
