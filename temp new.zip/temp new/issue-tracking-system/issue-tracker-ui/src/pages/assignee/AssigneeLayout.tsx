import { useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';
import { ErrorAlert } from '../../components/common/ErrorAlert';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { PageHeader } from '../../components/layout/PageHeader';
import { Sidebar } from '../../components/layout/Sidebar';
import { useAuth } from '../../hooks/useAuth';
import type { AssigneeData } from '../../hooks/useAssigneeData';
import type { Issue } from '../../models/Issue';
import type { Project } from '../../models/Project';
import { getErrorMessage } from '../../services/apiClient';
import projectService from '../../services/projectService';
import userService from '../../services/userService';

/** The data AssigneeLayout loads for the Assignee's pages. */
interface LoadedAssigneeData {
  issues: Issue[];
  projects: Project[];
}

/** Loads the Assignee's issues and all projects - two requests at the same time (Promise.all). */
async function fetchAssigneeData(assigneeId: number): Promise<LoadedAssigneeData> {
  const [issues, projects] = await Promise.all([
    userService.getIssuesAssignedToUser(assigneeId),
    projectService.getAllProjects(),
  ]);
  return { issues, projects };
}

/**
 * Frame of every Assignee page (a layout route in App.tsx): the sidebar - photo, name, email,
 * number of issues assigned and Logout, as the case study asks - and the selected page (<Outlet />).
 * It loads the Assignee's data once and passes it to the pages (see hooks/useAssigneeData.ts).
 */
export default function AssigneeLayout() {
  const { user } = useAuth();

  /** The loaded data - null until the first load has finished. */
  const [data, setData] = useState<LoadedAssigneeData | null>(null);
  /** Message of the last failed load ('' = no error). */
  const [error, setError] = useState('');

  /** id of the logged-in Assignee. */
  const assigneeId = user?.userId;

  // First load, when the layout appears
  useEffect(() => {
    if (assigneeId === undefined) {
      return;
    }
    let ignore = false;   // an outdated answer must not overwrite newer data
    fetchAssigneeData(assigneeId)
      .then((loadedData) => {
        if (!ignore) {
          setData(loadedData);
          setError('');
        }
      })
      .catch((loadError: unknown) => {
        if (!ignore) {
          setError(getErrorMessage(loadError));
        }
      });
    return () => {
      ignore = true;
    };
  }, [assigneeId]);

  /** Loads the data again ("Try again", or after a status change). Errors are shown by the layout. */
  async function reload(): Promise<void> {
    if (assigneeId === undefined) {
      return;
    }
    try {
      setData(await fetchAssigneeData(assigneeId));
      setError('');
    } catch (loadError) {
      setError(getErrorMessage(loadError));
    }
  }

  /** The right-hand side: spinner, error or the selected page. */
  let content;
  if (data === null && error) {
    content = (
      <>
        <PageHeader />
        <div className="p-4">
          <ErrorAlert message={error} onRetry={reload} />
        </div>
      </>
    );
  } else if (data === null) {
    content = (
      <>
        <PageHeader />
        <LoadingSpinner label="Loading your issues..." />
      </>
    );
  } else {
    /** What the Assignee pages receive through useAssigneeData(). */
    const assigneeData: AssigneeData = { ...data, reload };
    content = (
      <>
        {error && (
          <div className="px-4 pt-3">
            <ErrorAlert message={`Could not refresh the data: ${error}`} onRetry={reload} />
          </div>
        )}
        <Outlet context={assigneeData} />
      </>
    );
  }

  return (
    <div className="app-shell">
      <Sidebar stats={[{ label: 'Issues Assigned', value: data ? data.issues.length : '-' }]} links={[]} />
      <div className="app-content">{content}</div>
    </div>
  );
}
