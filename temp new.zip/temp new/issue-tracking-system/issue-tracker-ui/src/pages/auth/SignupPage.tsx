import { useState } from 'react';
import type { SubmitEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Avatar } from '../../components/common/Avatar';
import { AuthLayout } from '../../components/layout/AuthLayout';
import { SelectField } from '../../components/form/SelectField';
import { SubmitButton } from '../../components/form/SubmitButton';
import { TextField } from '../../components/form/TextField';
import { useForm } from '../../hooks/useForm';
import type { FormErrors, FormValues } from '../../hooks/useForm';
import { isRole } from '../../models/User';
import type { SignupSuccessState } from '../../routes/navigationState';
import { PATHS } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import userService from '../../services/userService';
import {
  validateEmail,
  validateImageUrl,
  validateName,
  validatePassword,
  validateRole,
  validateUsername,
} from '../../utils/validators';
import { ROLE_OPTIONS } from './roleOptions';

/** The fields of the sign-up form. */
interface SignupFormValues extends FormValues {
  username: string;  // unique handle
  name: string;      // full name (may repeat)
  email: string;
  password: string;
  profile: string;   // profile image URL (optional)
  role: string;
}

/** A blank sign-up form. */
const EMPTY_SIGNUP_FORM: SignupFormValues = { username: '', name: '', email: '', password: '', profile: '', role: '' };

/** Checks every field of the sign-up form; a field without a message is valid. */
function validateSignupForm(values: SignupFormValues): FormErrors<SignupFormValues> {
  return {
    username: validateUsername(values.username),
    name: validateName(values.name),
    email: validateEmail(values.email),
    password: validatePassword(values.password),
    profile: validateImageUrl(values.profile),
    role: validateRole(values.role),
  };
}

/**
 * Signup screen (Milestone 1) - both Project Owners and Assignees create their accounts here.
 * Same rules as the Login form, plus username (unique), name (may repeat) and an optional profile image URL.
 * On success the user is taken to the
 * Login page, which shows the backend's success message with the new email already filled in.
 */
export default function SignupPage() {
  const navigate = useNavigate();

  /** Form state and validation. */
  const form = useForm<SignupFormValues>(EMPTY_SIGNUP_FORM, validateSignupForm);

  /** True while the sign-up request is running. */
  const [submitting, setSubmitting] = useState(false);

  /** Error from the server (e.g. email already used). Empty = no error. */
  const [serverError, setServerError] = useState('');

  /** Profile URL without surrounding spaces - shown as a small preview once it is a valid image URL. */
  const profileUrl = form.values.profile.trim();

  /** Sends the sign-up request. */
  async function handleSubmit(event: SubmitEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    const selectedRole = form.values.role;
    if (!form.isValid || submitting || !isRole(selectedRole)) {
      return;
    }

    setSubmitting(true);
    setServerError('');
    try {
      const response = await userService.signUp({
        username: form.values.username.trim(),
        name: form.values.name.trim(),
        email: form.values.email.trim(),
        password: form.values.password,
        profile: profileUrl === '' ? null : profileUrl,   // no photo -> null (initials are shown)
        role: selectedRole,
      });
      // Go to Login and pass the message + email along (read by LoginPage)
      const state: SignupSuccessState = {
        signupMessage: `${response.message}. Please log in.`,
        email: response.user.email,
      };
      navigate(PATHS.LOGIN, { state });
    } catch (error) {
      setServerError(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthLayout title="Signup">
      {serverError && (
        <div className="alert alert-danger py-2" role="alert">
          {serverError}
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate>
        <TextField
          label="Name"
          name="name"
          placeholder="Enter name"
          autoComplete="name"
          value={form.values.name}
          error={form.getError('name')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <TextField
          label="Username"
          name="username"
          placeholder="Choose a username"
          autoComplete="username"
          helpText="Unique. 3-30 letters, numbers, dot, underscore or hyphen, e.g. priya.s"
          value={form.values.username}
          error={form.getError('username')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <TextField
          label="Email address"
          name="email"
          type="email"
          placeholder="Enter email"
          autoComplete="email"
          value={form.values.email}
          error={form.getError('email')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <TextField
          label="Password"
          name="password"
          type="password"
          placeholder="Password"
          autoComplete="new-password"
          value={form.values.password}
          error={form.getError('password')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <TextField
          label="Profile"
          name="profile"
          type="url"
          placeholder="Provide profile image url"
          helpText="Optional. Without a photo your initials are shown."
          value={form.values.profile}
          error={form.getError('profile')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        {profileUrl !== '' && !form.errors.profile && (
          <div className="d-flex align-items-center gap-2 mb-3">
            <Avatar name={form.values.name || 'New user'} imageUrl={profileUrl} size={44} />
            <span className="small text-muted">Profile preview</span>
          </div>
        )}
        <SelectField
          label="Role"
          name="role"
          placeholder="Select your role"
          options={ROLE_OPTIONS}
          value={form.values.role}
          error={form.getError('role')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <SubmitButton label="Signup" loadingLabel="Creating account..." loading={submitting} disabled={!form.isValid} />
      </form>

      <p className="text-center small mt-4 mb-0">
        Already have an account? <Link to={PATHS.LOGIN}>Login</Link>
      </p>
    </AuthLayout>
  );
}
