import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { FlashMessage } from '../../components/common/FlashMessage';
import { PageHeader } from '../../components/layout/PageHeader';
import { useAuth } from '../../hooks/useAuth';
import { useOwnerData } from '../../hooks/useOwnerData';
import { PATHS } from '../../routes/paths';
import { formatDate, isEndBeforeStart } from '../../utils/dateUtils';
import { ProjectIssues } from './ProjectIssues';

/**
 * Project Owner dashboard (Milestone 2).
 *  - header with the RegEx search box; sidebar comes from OwnerLayout
 *  - project drop-down (the owner's projects; the first one is selected by default)
 *  - owner name, start and end date (dd-mm-yyyy)
 *  - the selected project's issues in four columns, with assignee and priority filters (ProjectIssues)
 *  - "No Projects Available !" with a Create Project link when the owner has no project yet
 *
 * The selected project is kept in the URL (/owner/dashboard?projectId=2), so a page refresh, the Back
 * button, or a link from another page (e.g. after creating an issue) shows the same project.
 */
export default function OwnerDashboardPage() {
  const { user } = useAuth();
  const { projects, users } = useOwnerData();
  const [searchParams, setSearchParams] = useSearchParams();

  /** Text of the header's search box (filters the cards of the selected project). */
  const [searchText, setSearchText] = useState('');

  /** Look-up table userId -> User, for names and photos. */
  const usersById = new Map(users.map((u) => [u.userId, u]));

  /** The project chosen in the URL if it is one of the owner's projects, otherwise the first one. */
  const projectIdInUrl = Number(searchParams.get('projectId'));
  const selectedProject = projects.find((p) => p.projectId === projectIdInUrl) ?? projects[0];

  /** Drop-down change: put the new project id into the URL (which re-renders this page). */
  function handleProjectChange(projectId: string): void {
    setSearchParams({ projectId });
  }

  // No project yet: message + link to Create Project (the case study's "No Projects Screen")
  if (selectedProject === undefined) {
    return (
      <>
        <PageHeader searchText={searchText} onSearchChange={setSearchText} />
        <main className="p-4 text-center">
          <FlashMessage />
          <p className="text-danger fs-5 mt-4 mb-2">No Projects Available !</p>
          <Link to={PATHS.CREATE_PROJECT} className="btn btn-outline-warning btn-sm">
            Create Project
          </Link>
        </main>
      </>
    );
  }

  /** Owner's name: looked up by id, falling back to the logged-in user (who owns these projects). */
  const ownerName = usersById.get(selectedProject.projectOwnerId)?.name ?? user?.name ?? '';

  return (
    <>
      <PageHeader searchText={searchText} onSearchChange={setSearchText} />
      <main className="p-4">
        <FlashMessage />
        <h1 className="h6 fw-bold text-uppercase mb-3">Project Dashboard</h1>

        <div className="row g-3 mb-3">
          <div className="col-md-6">
            <label htmlFor="projectSelect" className="form-label small fw-semibold mb-1">
              Project Name
            </label>
            <select
              id="projectSelect"
              className="form-select form-select-sm"
              value={String(selectedProject.projectId)}
              onChange={(event) => handleProjectChange(event.target.value)}
            >
              {projects.map((project) => (
                <option key={project.projectId} value={String(project.projectId)}>
                  {project.projectName}
                </option>
              ))}
            </select>
            <div className="small text-muted mt-2">
              Start Date: {formatDate(selectedProject.startDate)} | End Date: {formatDate(selectedProject.endDate)}
              {isEndBeforeStart(selectedProject.startDate, selectedProject.endDate) && (
                <span className="text-danger ms-2">(end date is before the start date)</span>
              )}
            </div>
          </div>
          <div className="col-md-6 d-flex align-items-center">
            <span className="small fw-semibold me-2">Project Owner Name:</span>
            <span className="small fw-bold text-uppercase">{ownerName}</span>
          </div>
        </div>

        {/* key: a different project creates a fresh ProjectIssues (new issues, filters reset) */}
        <ProjectIssues
          key={selectedProject.projectId}
          projectId={selectedProject.projectId}
          usersById={usersById}
          searchText={searchText}
        />
      </main>
    </>
  );
}
