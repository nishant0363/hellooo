import { useEffect, useState } from 'react';
import { FilterSummary } from '../../components/board/FilterSummary';
import { IssueBoard } from '../../components/board/IssueBoard';
import { ErrorAlert } from '../../components/common/ErrorAlert';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { PRIORITIES, PRIORITY_LABELS, isPriority } from '../../models/Issue';
import type { Issue } from '../../models/Issue';
import { formatUserLabel } from '../../models/User';
import type { User } from '../../models/User';
import { getOwnerIssuePath } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import issueService from '../../services/issueService';
import { filterIssues } from '../../utils/issueFilters';

/** Props of ProjectIssues. */
interface ProjectIssuesProps {
  projectId: number;
  usersById: Map<number, User>;
  searchText: string;   // from the header's search box
}

/**
 * The selected project's issues: loads them, offers the two filters (assignee, priority) and shows
 * the board. All filtering happens in the browser.
 *
 * The dashboard renders this component with key={projectId}. When the project changes, React
 * therefore creates a NEW ProjectIssues, so its state (issues, filters, loading) starts fresh -
 * no issues of the previous project are ever shown under the new project's name.
 */
export function ProjectIssues({ projectId, usersById, searchText }: ProjectIssuesProps) {
  /** All issues of the project, as loaded. */
  const [issues, setIssues] = useState<Issue[]>([]);
  /** True until the issues have arrived. */
  const [loading, setLoading] = useState(true);
  /** Message of a failed load ('' = no error). */
  const [error, setError] = useState('');
  /** Increased by "Try again" to load the issues once more. */
  const [reloadCount, setReloadCount] = useState(0);
  /** Selected assignee filter: '' = everyone, otherwise the user id as text (select values are text). */
  const [assigneeFilter, setAssigneeFilter] = useState('');
  /** Selected priority filter: '' = all priorities. */
  const [priorityFilter, setPriorityFilter] = useState('');

  useEffect(() => {
    let ignore = false;   // see OwnerLayout: an outdated answer must not overwrite newer state

    async function loadIssues(): Promise<void> {
      try {
        const projectIssues = await issueService.getIssuesByProject(projectId);
        if (!ignore) {
          setIssues(projectIssues);
          setError('');
        }
      } catch (loadError) {
        if (!ignore) {
          setError(getErrorMessage(loadError));
        }
      } finally {
        if (!ignore) {
          setLoading(false);
        }
      }
    }

    loadIssues();
    return () => {
      ignore = true;
    };
  }, [projectId, reloadCount]);

  /** "Try again" after a failed load. */
  function retry(): void {
    setLoading(true);
    setError('');
    setReloadCount((count) => count + 1);
  }

  /** Clears both filters. */
  function clearFilters(): void {
    setAssigneeFilter('');
    setPriorityFilter('');
  }

  if (loading) {
    return <LoadingSpinner label="Loading issues..." />;
  }
  if (error) {
    return <ErrorAlert message={error} onRetry={retry} />;
  }

  /**
   * The project's team: every assignee who has an issue in it, sorted by name (assignee filter entries).
   * Shown as "Name (@username)", because two team members may have the same name.
   */
  const teamMembers = [...new Set(issues.map((issue) => issue.assigneeId))]
    .map((id) => {
      const member = usersById.get(id);
      return { id, label: member ? formatUserLabel(member) : `User #${id}` };
    })
    .sort((a, b) => a.label.localeCompare(b.label));

  /** The issues left after the search box and the two filters. */
  const visibleIssues = filterIssues(issues, {
    searchText,
    assigneeId: assigneeFilter === '' ? null : Number(assigneeFilter),
    priority: isPriority(priorityFilter) ? priorityFilter : null,
  });

  /** True when the user has narrowed the list in any way. */
  const isFiltered = searchText.trim() !== '' || assigneeFilter !== '' || priorityFilter !== '';

  return (
    <>
      <div className="row g-3 mb-2">
        <div className="col-md-6">
          <label htmlFor="assigneeFilter" className="form-label small fw-semibold mb-1">
            Filter by Assignee
          </label>
          <select
            id="assigneeFilter"
            className="form-select form-select-sm"
            value={assigneeFilter}
            onChange={(event) => setAssigneeFilter(event.target.value)}
          >
            <option value="">All</option>
            {teamMembers.map((member) => (
              <option key={member.id} value={String(member.id)}>
                {member.label}
              </option>
            ))}
          </select>
        </div>
        <div className="col-md-6">
          <label htmlFor="priorityFilter" className="form-label small fw-semibold mb-1">
            Filter by Priority
          </label>
          <select
            id="priorityFilter"
            className="form-select form-select-sm"
            value={priorityFilter}
            onChange={(event) => setPriorityFilter(event.target.value)}
          >
            <option value="">All</option>
            {PRIORITIES.map((priority) => (
              <option key={priority} value={priority}>
                {PRIORITY_LABELS[priority]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <FilterSummary
        searchText={searchText}
        shownCount={visibleIssues.length}
        totalCount={issues.length}
        isFiltered={isFiltered}
      >
        {(assigneeFilter !== '' || priorityFilter !== '') && (
          <button type="button" className="btn btn-link btn-sm p-0" onClick={clearFilters}>
            Clear filters
          </button>
        )}
      </FilterSummary>

      <IssueBoard
        issues={visibleIssues}
        usersById={usersById}
        getIssueLink={(issue) => getOwnerIssuePath(issue.issueId)}
      />
    </>
  );
}
