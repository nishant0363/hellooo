import { Link, useParams } from 'react-router-dom';
import { ErrorAlert } from '../../components/common/ErrorAlert';
import { FlashMessage } from '../../components/common/FlashMessage';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { IssueDetailsView } from '../../components/issue/IssueDetailsView';
import { PageHeader } from '../../components/layout/PageHeader';
import { useIssue } from '../../hooks/useIssue';
import { useOwnerData } from '../../hooks/useOwnerData';
import { PATHS, getEditIssuePath, getProjectBoardPath } from '../../routes/paths';

/**
 * Issue Details screen of the Project Owner (Milestone 5), opened by clicking a card on the board.
 * Shows every field of the issue, with "Project Board" in the breadcrumb to go back and an
 * "Edit Issue" button. Only issues of the owner's own projects are shown.
 */
export default function IssueDetailsPage() {
  /** The :issueId part of the URL /owner/issues/:issueId (always text). */
  const { issueId } = useParams();
  const { projects, users } = useOwnerData();
  const { issue, loading, error, reload } = useIssue(Number(issueId));

  /** The page body depends on the load: spinner, error, "not yours" or the details. */
  let content;
  if (loading) {
    content = <LoadingSpinner label="Loading issue..." />;
  } else if (issue === null) {
    content = (
      <>
        <ErrorAlert message={error} onRetry={reload} />
        <Link to={PATHS.OWNER_DASHBOARD}>Back to the project dashboard</Link>
      </>
    );
  } else {
    /** The issue's project - found only if the logged-in owner owns it. */
    const project = projects.find((p) => p.projectId === issue.projectId);
    if (project === undefined) {
      content = (
        <>
          <div className="alert alert-warning">
            Issue #{issue.issueId} belongs to a project you do not own, so it cannot be shown here.
          </div>
          <Link to={PATHS.OWNER_DASHBOARD}>Back to the project dashboard</Link>
        </>
      );
    } else {
      content = (
        <IssueDetailsView
          issue={issue}
          projectName={project.projectName}
          assignee={users.find((u) => u.userId === issue.assigneeId)}
          breadcrumbLabel="Project Board"
          breadcrumbTo={getProjectBoardPath(project.projectId)}
          actions={
            <Link to={getEditIssuePath(issue.issueId)} className="btn btn-dark btn-sm">
              <i className="bi bi-pencil me-1" aria-hidden="true"></i>
              Edit Issue
            </Link>
          }
        />
      );
    }
  }

  return (
    <>
      <PageHeader />
      <main className="p-4">
        <FlashMessage />
        {content}
      </main>
    </>
  );
}
