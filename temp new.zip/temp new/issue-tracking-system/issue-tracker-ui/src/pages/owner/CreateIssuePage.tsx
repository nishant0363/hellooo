import { useState } from 'react';
import type { SubmitEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FormActions } from '../../components/form/FormActions';
import { PageHeader } from '../../components/layout/PageHeader';
import { useAuth } from '../../hooks/useAuth';
import { useForm } from '../../hooks/useForm';
import { useOwnerData } from '../../hooks/useOwnerData';
import type { FlashMessageState } from '../../routes/navigationState';
import { PATHS, getProjectBoardPath } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import issueService from '../../services/issueService';
import {
  EMPTY_ISSUE_FORM,
  buildAssigneeOptions,
  buildProjectOptions,
  toIssueApiFields,
  validateIssueForm,
} from './issueForm';
import type { IssueFormValues } from './issueForm';
import { IssueFormFields } from './IssueFormFields';

/**
 * Create Issue screen (Milestone 4).
 *  - all the fields of the case study (see issueForm.ts for the rules) in a two-column form
 *  - Project: the logged-in owner's projects; Assignee: every user with the Assignee role
 *  - CREATE only works for a valid form and is disabled while the request runs; on success the owner
 *    goes to that project's board, on failure the server's message is shown. RESET blanks every field.
 */
export default function CreateIssuePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { projects, users, reload } = useOwnerData();

  /** Form state and validation (rules shared with Edit Issue). */
  const form = useForm<IssueFormValues>(EMPTY_ISSUE_FORM, validateIssueForm);
  /** True while the create request is running. */
  const [submitting, setSubmitting] = useState(false);
  /** Error from the server. Empty = no error. */
  const [serverError, setServerError] = useState('');

  /** Project drop-down: the owner's own projects. Assignee drop-down: every Assignee. */
  const projectOptions = buildProjectOptions(projects);
  const assigneeOptions = buildAssigneeOptions(users);

  /** Sends the create request; on success refreshes the shared data, then opens the project's board. */
  async function handleSubmit(event: SubmitEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    const fields = toIssueApiFields(form.values);
    if (!form.isValid || submitting || fields === null || user === null) {
      return;
    }

    setSubmitting(true);
    setServerError('');
    try {
      const response = await issueService.createIssue({ ...fields, createdBy: user.userId });
      const created = response.issue;
      await reload();   // sidebar "Issues Created" count
      const state: FlashMessageState = {
        flashMessage: `Issue #${created.issueId} "${created.summary}" was created successfully.`,
      };
      navigate(getProjectBoardPath(created.projectId), { state });
    } catch (error) {
      setServerError(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  /** RESET: every field back to blank, messages hidden. */
  function handleReset(): void {
    form.reset();
    setServerError('');
  }

  // An issue always belongs to a project, so without a project there is nothing to create yet
  if (projects.length === 0) {
    return (
      <>
        <PageHeader />
        <main className="p-4">
          <h1 className="h5 fw-bold mb-3">Create Issue</h1>
          <p className="text-muted">You need a project before you can create issues.</p>
          <Link to={PATHS.CREATE_PROJECT} className="btn btn-outline-warning btn-sm">
            Create Project
          </Link>
        </main>
      </>
    );
  }

  return (
    <>
      <PageHeader />
      <main className="p-4">
        <h1 className="h5 fw-bold mb-3">Create Issue</h1>

        {serverError && (
          <div className="alert alert-danger py-2" role="alert">
            {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <IssueFormFields form={form} projectOptions={projectOptions} assigneeOptions={assigneeOptions} />
          <FormActions
            submitLabel="CREATE"
            submittingLabel="Creating..."
            submitting={submitting}
            canSubmit={form.isValid}
            onReset={handleReset}
          />
        </form>
      </main>
    </>
  );
}
