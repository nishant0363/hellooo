import { useState } from 'react';
import type { SubmitEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { FormActions } from '../../components/form/FormActions';
import { SelectField } from '../../components/form/SelectField';
import type { SelectOption } from '../../components/form/SelectField';
import { TextField } from '../../components/form/TextField';
import { PageHeader } from '../../components/layout/PageHeader';
import { useAuth } from '../../hooks/useAuth';
import { useForm } from '../../hooks/useForm';
import type { FormErrors, FormValues } from '../../hooks/useForm';
import { useOwnerData } from '../../hooks/useOwnerData';
import { formatUserLabel } from '../../models/User';
import type { FlashMessageState } from '../../routes/navigationState';
import { getProjectBoardPath } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import projectService from '../../services/projectService';
import {
  validateEndDate,
  validateRequired,
  validateSafeText,
  validateSelection,
} from '../../utils/validators';

/** Longest project name allowed (case study). */
const PROJECT_NAME_MAX_LENGTH = 150;

/** The fields of the Create Project form (all text; dates are "yyyy-MM-dd" from the date pickers). */
interface ProjectFormValues extends FormValues {
  projectName: string;
  projectOwnerId: string;   // user id as text - always the logged-in owner (the drop-down is locked)
  startDate: string;
  endDate: string;
}

/** A blank form for this owner - the starting state and what Reset returns to (the owner stays filled in). */
function emptyProjectForm(ownerId: string): ProjectFormValues {
  return { projectName: '', projectOwnerId: ownerId, startDate: '', endDate: '' };
}

/** Checks every field of the form; a field without a message is valid. */
function validateProjectForm(values: ProjectFormValues): FormErrors<ProjectFormValues> {
  return {
    projectName: validateSafeText(values.projectName, 'Project name', 1, PROJECT_NAME_MAX_LENGTH),
    projectOwnerId: validateSelection(values.projectOwnerId, 'the project owner'),
    startDate: validateRequired(values.startDate, 'Start date'),
    endDate: validateEndDate(values.startDate, values.endDate),
  };
}

/**
 * Create Project screen (Milestone 3).
 *  - Project Name: required, max 150 characters, only - / | . as special characters
 *  - Project Owner: the drop-down of Project Owners loaded from the API, LOCKED to the logged-in owner.
 *    A project only appears on its owner's dashboard, so an owner creating a project for someone else would
 *    lose it at once (and hand work to people without asking). The owner sent to the API is therefore
 *    always the logged-in user from AuthContext, not a value the form could change.
 *  - Start and End Date: date pickers, end date not before start date
 *  - CREATE only works for a valid form and is disabled while the request runs; on success the user goes
 *    to the new project's board, on failure the server's message is shown. RESET blanks the name and the
 *    dates (the owner stays you).
 */
export default function CreateProjectPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { users, reload } = useOwnerData();

  /** id of the logged-in owner as text ('' only if nobody is logged in, which ProtectedRoute prevents). */
  const myOwnerId = user ? String(user.userId) : '';

  /** Form state and validation, starting with the owner filled in. */
  const form = useForm<ProjectFormValues>(emptyProjectForm(myOwnerId), validateProjectForm);
  /** True while the create request is running. */
  const [submitting, setSubmitting] = useState(false);
  /** Error from the server (e.g. name already used). Empty = no error. */
  const [serverError, setServerError] = useState('');

  /** Owner drop-down: the Project Owners from the API ("Name (@username)"); the logged-in owner is marked "(you)". */
  const ownerOptions: SelectOption[] = users
    .filter((u) => u.role === 'PROJECT_OWNER')
    .map((u) => ({
      value: String(u.userId),
      label: u.userId === user?.userId ? `${formatUserLabel(u)} (you)` : formatUserLabel(u),
    }));
  // Safety net: if the user list was loaded before this owner existed, still show them
  if (user !== null && !ownerOptions.some((option) => option.value === myOwnerId)) {
    ownerOptions.push({ value: myOwnerId, label: `${formatUserLabel(user)} (you)` });
  }

  /** Sends the create request; on success refreshes the shared data, then opens the dashboard. */
  async function handleSubmit(event: SubmitEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    if (!form.isValid || submitting || user === null) {
      return;
    }

    setSubmitting(true);
    setServerError('');
    try {
      const response = await projectService.createProject({
        projectName: form.values.projectName.trim(),
        projectOwnerId: user.userId,   // always the logged-in owner
        startDate: form.values.startDate,
        endDate: form.values.endDate,
      });
      const created = response.project;

      // Refresh the sidebar count and the project list BEFORE leaving, so the dashboard already has it
      await reload();

      // Open the new project's board with a one-time success message
      const state: FlashMessageState = { flashMessage: `Project "${created.projectName}" was created successfully.` };
      navigate(getProjectBoardPath(created.projectId), { state });
    } catch (error) {
      setServerError(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  /** RESET: name and dates back to blank (the owner stays you), messages hidden. */
  function handleReset(): void {
    form.reset();
    setServerError('');
  }

  return (
    <>
      <PageHeader />
      <main className="p-4">
        <h1 className="h5 fw-bold mb-3">Create Project</h1>

        {serverError && (
          <div className="alert alert-danger py-2" role="alert">
            {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="row gx-4">
            <div className="col-md-6">
              <TextField
                label="Project Name"
                name="projectName"
                placeholder="Enter project name"
                value={form.values.projectName}
                error={form.getError('projectName')}
                onChange={form.handleChange}
                onBlur={form.handleBlur}
              />
            </div>
            <div className="col-md-6">
              <SelectField
                label="Project Owner"
                name="projectOwnerId"
                placeholder="Select project owner"
                options={ownerOptions}
                value={form.values.projectOwnerId}
                error={form.getError('projectOwnerId')}
                onChange={form.handleChange}
                onBlur={form.handleBlur}
                disabled
              />
            </div>
            <div className="col-md-6">
              <TextField
                label="Project Start Date"
                name="startDate"
                type="date"
                value={form.values.startDate}
                error={form.getError('startDate')}
                onChange={form.handleChange}
                onBlur={form.handleBlur}
              />
            </div>
            <div className="col-md-6">
              <TextField
                label="Project End Date"
                name="endDate"
                type="date"
                min={form.values.startDate || undefined}
                value={form.values.endDate}
                error={form.getError('endDate')}
                onChange={form.handleChange}
                onBlur={form.handleBlur}
              />
            </div>
          </div>

          <FormActions
            submitLabel="CREATE"
            submittingLabel="Creating..."
            submitting={submitting}
            canSubmit={form.isValid}
            onReset={handleReset}
          />
        </form>
      </main>
    </>
  );
}
