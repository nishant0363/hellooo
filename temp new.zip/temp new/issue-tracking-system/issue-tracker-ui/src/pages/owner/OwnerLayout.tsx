import { useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';
import { ErrorAlert } from '../../components/common/ErrorAlert';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { PageHeader } from '../../components/layout/PageHeader';
import { Sidebar } from '../../components/layout/Sidebar';
import type { SidebarLink } from '../../components/layout/Sidebar';
import { useAuth } from '../../hooks/useAuth';
import type { OwnerData } from '../../hooks/useOwnerData';
import type { Project } from '../../models/Project';
import type { User } from '../../models/User';
import { PATHS } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import issueService from '../../services/issueService';
import projectService from '../../services/projectService';
import userService from '../../services/userService';

/** The Project Owner's navigation links (sidebar). */
const OWNER_LINKS: SidebarLink[] = [
  { to: PATHS.OWNER_DASHBOARD, label: 'Project Dashboard', icon: 'bi-kanban' },
  { to: PATHS.CREATE_PROJECT, label: 'Create Project', icon: 'bi-plus-square' },
  { to: PATHS.CREATE_ISSUE, label: 'Create Issue', icon: 'bi-bug' },
];

/** The three pieces of data OwnerLayout loads for the owner pages. */
interface LoadedOwnerData {
  projects: Project[];
  users: User[];
  issuesCreatedCount: number;
}

/**
 * Loads the owner's projects, all users and the issues the owner created - three requests sent at
 * the same time with Promise.all (much faster than one after the other). If any request fails,
 * the whole Promise fails and the caller shows the error.
 */
async function fetchOwnerData(ownerId: number): Promise<LoadedOwnerData> {
  const [projects, users, createdIssues] = await Promise.all([
    projectService.getProjectsByOwner(ownerId),
    userService.getAllUsers(),
    issueService.getIssuesByOwner(ownerId),
  ]);
  return { projects, users, issuesCreatedCount: createdIssues.length };
}

/**
 * Frame of every Project Owner page (a "layout route" in App.tsx): the sidebar on the left and the
 * selected page on the right (<Outlet />).
 *
 * It loads the data several owner pages need and hands it to them through the Outlet context
 * (see hooks/useOwnerData.ts), so each page does not have to load it again.
 */
export default function OwnerLayout() {
  const { user } = useAuth();

  /** The loaded data - null until the first load has finished (a spinner is shown until then). */
  const [data, setData] = useState<LoadedOwnerData | null>(null);
  /** Message of the last failed load ('' = no error). */
  const [error, setError] = useState('');

  /** id of the logged-in owner (undefined only if nobody is logged in). */
  const ownerId = user?.userId;

  // First load, when the layout appears
  useEffect(() => {
    if (ownerId === undefined) {
      return;
    }
    // "ignore" is set when this effect is cleaned up (the owner changed or the page closed), so an
    // outdated answer can never overwrite newer data
    let ignore = false;
    fetchOwnerData(ownerId)
      .then((loadedData) => {
        if (!ignore) {
          setData(loadedData);
          setError('');
        }
      })
      .catch((loadError: unknown) => {
        if (!ignore) {
          setError(getErrorMessage(loadError));
        }
      });
    return () => {
      ignore = true;
    };
  }, [ownerId]);

  /**
   * Loads the data again ("Try again", or after a project/issue was created). The current page stays
   * visible meanwhile. Errors are shown by the layout, so the returned Promise never fails.
   */
  async function reload(): Promise<void> {
    if (ownerId === undefined) {
      return;
    }
    try {
      setData(await fetchOwnerData(ownerId));
      setError('');
    } catch (loadError) {
      setError(getErrorMessage(loadError));
    }
  }

  /** The right-hand side: spinner, error or the selected page. */
  let content;
  if (data === null && error) {
    content = (
      <>
        <PageHeader />
        <div className="p-4">
          <ErrorAlert message={error} onRetry={reload} />
        </div>
      </>
    );
  } else if (data === null) {
    content = (
      <>
        <PageHeader />
        <LoadingSpinner label="Loading your projects..." />
      </>
    );
  } else {
    /** What the owner pages receive through useOwnerData(). */
    const ownerData: OwnerData = { ...data, reload };
    content = (
      <>
        {error && (
          <div className="px-4 pt-3">
            <ErrorAlert message={`Could not refresh the data: ${error}`} onRetry={reload} />
          </div>
        )}
        <Outlet context={ownerData} />
      </>
    );
  }

  return (
    <div className="app-shell">
      <Sidebar
        stats={[
          { label: 'Projects Created', value: data ? data.projects.length : '-' },
          { label: 'Issues Created', value: data ? data.issuesCreatedCount : '-' },
        ]}
        links={OWNER_LINKS}
      />
      <div className="app-content">{content}</div>
    </div>
  );
}
