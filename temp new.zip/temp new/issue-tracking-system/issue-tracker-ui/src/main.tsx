import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

// Global styles: Bootstrap first, then the icon font, then our own rules (which may override Bootstrap)
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './index.css';

import App from './App';
import { AuthProvider } from './context/AuthProvider';

/** The <div id="root"> in index.html that React fills with the application. */
const rootElement = document.getElementById('root');
if (rootElement === null) {
  throw new Error('index.html must contain <div id="root"></div>');
}

/**
 * Start-up. The wrappers, from the outside in:
 *  - StrictMode: development-only checks that warn about unsafe code (no effect in the production build)
 *  - BrowserRouter: enables page navigation with real URLs (/login, /owner/dashboard ...)
 *  - AuthProvider: makes the logged-in user available to every page
 */
createRoot(rootElement).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>,
);
