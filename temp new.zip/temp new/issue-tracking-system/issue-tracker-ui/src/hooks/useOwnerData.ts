import { useOutletContext } from 'react-router-dom';
import type { Project } from '../models/Project';
import type { User } from '../models/User';

/**
 * Data that OwnerLayout loads ONCE for all Project Owner pages and passes down with
 * <Outlet context={...} />: the sidebar numbers, the dashboard, and (later) the create/edit forms all
 * use it, so the same requests are not repeated on every page.
 */
export interface OwnerData {
  /** Projects owned by the logged-in owner, in the order the API returns them. */
  projects: Project[];
  /** Every user - for assignee names and photos, and the owner/assignee drop-downs. */
  users: User[];
  /** How many issues the logged-in owner has created (sidebar). */
  issuesCreatedCount: number;
  /**
   * Loads everything again, e.g. after a project or issue was created. It returns a Promise, so a page
   * can `await reload()` and only then move on - the next page then already sees the new data.
   */
  reload: () => Promise<void>;
}

/** Reads the OwnerData given by OwnerLayout. Only works in pages rendered inside OwnerLayout. */
export function useOwnerData(): OwnerData {
  return useOutletContext<OwnerData>();
}
