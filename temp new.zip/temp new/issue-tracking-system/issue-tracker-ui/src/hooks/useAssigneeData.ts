import { useOutletContext } from 'react-router-dom';
import type { Issue } from '../models/Issue';
import type { Project } from '../models/Project';

/**
 * Data that AssigneeLayout loads once for the Assignee's pages and passes down with
 * <Outlet context={...} /> (same idea as useOwnerData for the Project Owner).
 */
export interface AssigneeData {
  /** Issues assigned to the logged-in Assignee. */
  issues: Issue[];
  /** Every project - to show the project name of an issue. */
  projects: Project[];
  /** Loads everything again, e.g. after a status change. */
  reload: () => Promise<void>;
}

/** Reads the AssigneeData given by AssigneeLayout. Only works in pages rendered inside AssigneeLayout. */
export function useAssigneeData(): AssigneeData {
  return useOutletContext<AssigneeData>();
}
