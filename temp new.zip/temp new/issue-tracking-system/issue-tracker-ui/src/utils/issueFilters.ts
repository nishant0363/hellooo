import type { Issue, IssueStatus, Priority } from '../models/Issue';

/** The filters of a board. Empty values mean "no filter". */
export interface IssueFilterOptions {
  searchText: string;           // matched against summary and description
  assigneeId: number | null;    // only issues of this assignee
  priority: Priority | null;    // only issues with this priority
}

/** Result of turning the search box text into a test. */
export interface SearchMatcher {
  matches: (text: string) => boolean;
  isValidRegex: boolean;        // false when the text was not a valid regular expression
}

/**
 * Builds the search test from the search box text.
 * The case study asks for a RegEx match, so the text is used as a regular expression ("i" = ignore case):
 * "^add" finds summaries starting with "add", "login|password" finds either word.
 * A half-typed pattern such as "[" or "(" is not a valid RegEx - instead of crashing, the text is then
 * matched as plain text, and isValidRegex tells the page to show a small hint.
 */
export function buildSearchMatcher(searchText: string): SearchMatcher {
  const text = searchText.trim();
  if (text === '') {
    return { matches: () => true, isValidRegex: true };
  }
  try {
    const pattern = new RegExp(text, 'i');
    return { matches: (value) => pattern.test(value), isValidRegex: true };
  } catch {
    const lowerText = text.toLowerCase();
    return { matches: (value) => value.toLowerCase().includes(lowerText), isValidRegex: false };
  }
}

/**
 * Applies the search text and the two filters. All filtering happens here in the browser
 * (the case study: "data filtering must be done on Front-end itself"), so changing a filter needs no API call.
 */
export function filterIssues(issues: Issue[], options: IssueFilterOptions): Issue[] {
  const search = buildSearchMatcher(options.searchText);
  return issues.filter(
    (issue) =>
      (options.assigneeId === null || issue.assigneeId === options.assigneeId) &&
      (options.priority === null || issue.priority === options.priority) &&
      (search.matches(issue.summary) || search.matches(issue.description ?? '')),
  );
}

/**
 * Sorts issues into the four board columns: { TO_DO: [...], DEVELOPMENT: [...], ... }.
 * The return type Record<IssueStatus, Issue[]> makes TypeScript check that every status has a column.
 */
export function groupIssuesByStatus(issues: Issue[]): Record<IssueStatus, Issue[]> {
  const withStatus = (status: IssueStatus): Issue[] => issues.filter((issue) => issue.status === status);
  return {
    TO_DO: withStatus('TO_DO'),
    DEVELOPMENT: withStatus('DEVELOPMENT'),
    TESTING: withStatus('TESTING'),
    COMPLETED: withStatus('COMPLETED'),
  };
}
