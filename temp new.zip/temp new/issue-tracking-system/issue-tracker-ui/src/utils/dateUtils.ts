/**
 * Date helpers. The backend sends dates as ISO text: "2026-09-01" (a date) or "2026-10-11T14:05:33"
 * (a date and time). The screens show them as dd-mm-yyyy, as the case study asks.
 *
 * The text is cut apart instead of using new Date("2026-09-01"): JavaScript reads a date-only string as
 * midnight UTC, which in some time zones (e.g. the US) is still the PREVIOUS day - the wrong date would be shown.
 */

/** "2026-09-01" or "2026-09-01T10:30:00" -> "01-09-2026". Returns "-" for a missing or unexpected value. */
export function formatDate(isoValue: string | null | undefined): string {
  if (!isoValue || isoValue.length < 10) {
    return '-';
  }
  const [year, month, day] = isoValue.substring(0, 10).split('-');
  if (!year || !month || !day) {
    return '-';
  }
  return `${day}-${month}-${year}`;
}

/** "2026-10-11T14:05:33" -> "11-10-2026 | 14:05". Falls back to the date alone when there is no time. */
export function formatDateTime(isoValue: string | null | undefined): string {
  const date = formatDate(isoValue);
  if (!isoValue || date === '-' || isoValue.length < 16) {
    return date;
  }
  const time = isoValue.substring(11, 16);   // "HH:mm"
  return `${date} | ${time}`;
}

/**
 * True when an end date is before the start date. ISO dates ("yyyy-MM-dd") sort correctly as plain
 * text, so a string comparison is enough.
 */
export function isEndBeforeStart(startDate: string | null, endDate: string | null): boolean {
  if (!startDate || !endDate) {
    return false;
  }
  return endDate < startDate;
}
