import { useState } from 'react';
import type { ReactNode } from 'react';
import { AuthContext } from './AuthContext';
import type { AuthContextValue } from './AuthContext';
import { isUser } from '../models/User';
import type { User } from '../models/User';

/** Key under which the logged-in user is saved in the browser's sessionStorage. */
const STORAGE_KEY = 'its.loggedInUser';

/**
 * Reads the user saved by a previous login in this browser tab, so a page refresh does not log the
 * user out. sessionStorage is cleared when the tab is closed, which is safer than localStorage.
 * Anything wrong (nothing saved, broken JSON, wrong shape, storage blocked) simply means "not logged in".
 */
function readSavedUser(): User | null {
  try {
    const saved = sessionStorage.getItem(STORAGE_KEY);
    if (!saved) {
      return null;
    }
    const parsed: unknown = JSON.parse(saved);
    return isUser(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/** Props of AuthProvider: the part of the app that can use the context. */
interface AuthProviderProps {
  children: ReactNode;
}

/**
 * Holds the logged-in user in React state and offers it to every component below it.
 * It wraps the whole app in main.tsx.
 *
 * Note: only the user's public data (id, name, email, photo, role) is stored - the backend never
 * returns the password. Our backend has no tokens (JWT), so this is the frontend's login session.
 */
export function AuthProvider({ children }: AuthProviderProps) {
  // Passing the function (not its result) makes React call it only once, on the first render
  const [user, setUser] = useState<User | null>(readSavedUser);

  /** Saves the user in state (re-renders the app) and in sessionStorage (survives a refresh). */
  function login(loggedInUser: User): void {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(loggedInUser));
    } catch {
      // Storage can be blocked (e.g. some private modes) - the app still works until a refresh
    }
    setUser(loggedInUser);
  }

  /** Removes the user from state and from sessionStorage. */
  function logout(): void {
    try {
      sessionStorage.removeItem(STORAGE_KEY);
    } catch {
      // Nothing to clean up if storage is blocked
    }
    setUser(null);
  }

  const value: AuthContextValue = { user, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
