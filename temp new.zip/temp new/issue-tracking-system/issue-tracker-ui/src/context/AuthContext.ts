import { createContext } from 'react';
import type { User } from '../models/User';

/**
 * What any component can read from the authentication context: who is logged in, and the two
 * actions that change it. The context lets the Login page, the route guards and (later) the
 * sidebar share the same logged-in user without passing props through every level.
 */
export interface AuthContextValue {
  /** The logged-in user, or null when nobody is logged in. */
  user: User | null;
  /** Remembers the user after a successful login. */
  login: (user: User) => void;
  /** Forgets the user (Logout button). */
  logout: () => void;
}

/**
 * The context object. Its default value is undefined, which only happens when a component is used
 * outside <AuthProvider> - a programming mistake that the useAuth hook reports clearly.
 */
export const AuthContext = createContext<AuthContextValue | undefined>(undefined);
