import axios from 'axios';
import type { ApiErrorResponse } from '../models/ApiError';

/**
 * Address of the API Gateway. It can be changed in an optional .env file (see .env.example);
 * without one, the default http://localhost:8080/api is used.
 */
const API_BASE_URL: string = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080/api';

/** How long (in milliseconds) to wait for an answer before giving up. */
const REQUEST_TIMEOUT_MS = 10000;

/**
 * One shared Axios instance for the whole application.
 * Every service file (userService, projectService, issueService) uses it, so the base URL, the JSON
 * header and the timeout are configured in ONE place. A call like apiClient.get('/users') goes to
 * http://localhost:8080/api/users, and the gateway forwards it to the User Service.
 */
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: REQUEST_TIMEOUT_MS,
  headers: { 'Content-Type': 'application/json' },
});

/**
 * Turns any error thrown by an API call into ONE readable sentence for the screen.
 *
 * Three cases:
 *  1. The server answered with an error status (400, 401, 404, 409, 503 ...): show the backend's own
 *     message (our services always send { message: "..." }), or the field messages for a 400. Errors
 *     created by the gateway itself (500/502/503/504 when a service is down) have no message, so a
 *     fixed sentence is used for those.
 *  2. The request timed out.
 *  3. No answer at all: the gateway is not running, or the network/CORS blocked the call.
 */
export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError<ApiErrorResponse>(error)) {
    // Case 1 - the server answered
    if (error.response) {
      const status = error.response.status;
      const data = error.response.data;
      if (typeof data === 'object' && data !== null) {
        if (data.fieldErrors && Object.keys(data.fieldErrors).length > 0) {
          return Object.values(data.fieldErrors).join('. ');
        }
        if (data.message) {
          return data.message;
        }
      }
      // Errors made by the gateway itself (not by a service) have no "message", so we word them here
      if (status === 502 || status === 503) {
        return 'A required service is not available right now. Please try again in a moment.';
      }
      if (status === 504) {
        return 'The server took too long to answer. Please try again.';
      }
      if (status === 500) {
        return 'The server could not complete this request. Please try again in a moment.';
      }
      return `The request failed (status ${status}). Please try again.`;
    }
    // Case 2 - timeout
    if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
      return 'The server took too long to answer. Please try again.';
    }
    // Case 3 - no answer
    return 'Cannot reach the server. Please check that the backend (API Gateway on port 8080) is running.';
  }
  return 'Something went wrong. Please try again.';
}

export default apiClient;
