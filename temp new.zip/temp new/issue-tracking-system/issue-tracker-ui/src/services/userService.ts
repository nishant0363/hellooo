import apiClient from './apiClient';
import type { Issue } from '../models/Issue';
import type { LoginRequest, LoginResponse, SignUpRequest, SignUpResponse, User } from '../models/User';

/**
 * All calls to the User Service (through the gateway: /api/users/...).
 *
 * Components never call Axios directly - they call these functions. So if a URL changes,
 * only this file changes, and every function says exactly what it sends and what it returns.
 * The generic in apiClient.post<LoginResponse>(...) tells TypeScript the shape of response.data.
 */
const userService = {
  /** POST /api/users/login - checks email + password. 401 when they are wrong. */
  async login(request: LoginRequest): Promise<LoginResponse> {
    const response = await apiClient.post<LoginResponse>('/users/login', request);
    return response.data;
  },

  /** POST /api/users - creates a new account. 409 when the email or username is already used. */
  async signUp(request: SignUpRequest): Promise<SignUpResponse> {
    const response = await apiClient.post<SignUpResponse>('/users', request);
    return response.data;
  },

  /**
   * GET /api/users/{userId}/issues - the issues assigned to a user. The User Service asks the Issue
   * Service for them (Feign call through Eureka), so this one request crosses two microservices.
   */
  async getIssuesAssignedToUser(userId: number): Promise<Issue[]> {
    const response = await apiClient.get<Issue[]>(`/users/${userId}/issues`);
    return response.data;
  },

  /** GET /api/users - every user (for assignee names and photos, and the owner/assignee drop-downs). */
  async getAllUsers(): Promise<User[]> {
    const response = await apiClient.get<User[]>('/users');
    return response.data;
  },
};

export default userService;
