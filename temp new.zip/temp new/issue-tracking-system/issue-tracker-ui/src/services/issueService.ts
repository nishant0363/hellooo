import apiClient from './apiClient';
import type { CreateIssueRequest, Issue, IssueSavedResponse, UpdateIssueRequest } from '../models/Issue';

/** All calls to the Issue Service (through the gateway: /api/issues/...). */
const issueService = {
  /**
   * GET /api/issues/project/{projectId} - the issues of one project.
   * (Called on the Issue Service directly rather than /api/projects/{id}/issues, which would add one
   * more service-to-service hop: the project is already known because it came from the project list.)
   */
  async getIssuesByProject(projectId: number): Promise<Issue[]> {
    const response = await apiClient.get<Issue[]>(`/issues/project/${projectId}`);
    return response.data;
  },

  /** GET /api/issues/owner/{ownerId} - the issues CREATED by one Project Owner. */
  async getIssuesByOwner(ownerId: number): Promise<Issue[]> {
    const response = await apiClient.get<Issue[]>(`/issues/owner/${ownerId}`);
    return response.data;
  },

  /** GET /api/issues/{id} - one issue. 404 when it does not exist. */
  async getIssueById(issueId: number): Promise<Issue> {
    const response = await apiClient.get<Issue>(`/issues/${issueId}`);
    return response.data;
  },

  /**
   * PUT /api/issues/{id} - changes the fields that are sent. The Issue Service checks a new project
   * (must exist) and a new assignee (must be an Assignee) with the other services.
   */
  async updateIssue(issueId: number, request: UpdateIssueRequest): Promise<IssueSavedResponse> {
    const response = await apiClient.put<IssueSavedResponse>(`/issues/${issueId}`, request);
    return response.data;
  },

  /**
   * POST /api/issues - creates an issue. The Issue Service checks with the other services that the
   * project exists, the creator is a Project Owner and the assignee is an Assignee (400 otherwise).
   */
  async createIssue(request: CreateIssueRequest): Promise<IssueSavedResponse> {
    const response = await apiClient.post<IssueSavedResponse>('/issues', request);
    return response.data;
  },
};

export default issueService;
