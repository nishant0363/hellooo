# Issue Tracking System - React frontend (Week 4)

The web screens for the Issue Tracking System. It talks **only to the API Gateway** (`http://localhost:8080/api`),
which forwards each call to the User, Project or Issue microservice built in Week 3.

**Stack:** React 19 + TypeScript (created with Vite), React Router 7 (`react-router-dom`), Axios, Bootstrap 5 and
Bootstrap Icons. Linting with oxlint (the Vite template's linter), with `any` forbidden.

## Run it

1. **Node.js 20.19 or newer** (22 or 24 LTS recommended). Check with `node -v`.
2. Start the backend first (MySQL, `eureka-server`, the three services and `api-gateway` - see the main README).
3. In a terminal opened in this `issue-tracker-ui` folder:

   ```
   npm install      (first time only - downloads the libraries into node_modules)
   npm run dev      (starts the development server)
   ```

4. Open **http://localhost:5173**. The gateway's CORS settings already allow this address.

| Script              | What it does                                                    |
|---------------------|-----------------------------------------------------------------|
| `npm run dev`       | Development server with instant reload on every save            |
| `npm run build`     | Type-checks everything (`tsc -b`), then builds `dist/` for production |
| `npm run typecheck` | Type-check only                                                 |
| `npm run lint`      | oxlint (code-quality rules, no `any`)                           |
| `npm run preview`   | Serves the production build from `dist/` on http://localhost:4173 |

The API address defaults to `http://localhost:8080/api`. To change it without touching the code, copy
`.env.example` to `.env` and edit `VITE_API_BASE_URL` (then restart `npm run dev`).

### Demo logins (created by the backend on a fresh database)

| Email            | Password       | Role          |
|------------------|----------------|---------------|
| priya@its.com    | `Owner@123`    | Project Owner |
| karan@its.com    | `Owner@123`    | Project Owner |
| rahul@its.com    | `Assignee@123` | Assignee      |
| ananya@its.com   | `Assignee@123` | Assignee      |

## Folder structure

```
src/
├── main.tsx              start-up: Bootstrap CSS, BrowserRouter, AuthProvider, App
├── App.tsx               route table (which page for which URL, guarded by role)
├── index.css             app colours and the few styles Bootstrap has no class for
├── appConfig.ts          application name
├── models/               TypeScript types of the backend's JSON (User, ApiErrorResponse ...)
├── services/             apiClient (one Axios instance + error messages) and one file per microservice
├── context/              AuthContext + AuthProvider: the logged-in user, shared with every page
├── hooks/                useAuth, useForm, useOwnerData / useAssigneeData (layout data), useIssue (load one issue)
├── utils/                validators, dateUtils (dd-mm-yyyy), issueFilters (search/filters/columns), tagUtils
├── routes/               paths, ProtectedRoute (role guard), GuestRoute (login/signup only when logged out)
├── components/
│   ├── form/             TextField, TextAreaField, SelectField, SubmitButton, FormActions - used by every form
│   ├── layout/           AuthLayout (Login/Signup frame), Sidebar, PageHeader (yellow bar + search)
│   ├── board/            IssueBoard -> IssueColumn -> IssueCard (shared by both dashboards)
│   ├── issue/            IssueDetailsView (read-only issue page, shared by both roles)
│   └── common/           Avatar, PriorityBadge, TagChips, LoadingSpinner, ErrorAlert, FlashMessage
└── pages/                one component per screen: auth/, owner/ (OwnerLayout + pages), assignee/ (AssigneeLayout + pages)
```

## Milestones

| Milestone | Screen(s)                                   | Status |
|-----------|---------------------------------------------|--------|
| 1         | Login, Signup, role-based redirect, logout  | Done   |
| 2         | Project Owner dashboard (sidebar, search, board, filters, no-projects) | Done |
| 3         | Create Project                              | Done   |
| 4         | Create Issue                                | Done   |
| 5         | Issue Details + Edit Issue                  | Done   |
| 6         | Assignee dashboard + status update          | Done   |
| 7         | Back-end API integration (services, models, every screen on the real API) | Done |
| 8         | GitHub                                      | -      |

## Design decisions and assumptions

**Forms.** The case study names Angular's "template-driven" and "reactive" forms. React has no such split, so every
form uses the React equivalent of a reactive form: *controlled inputs* whose values live in state, plus a
`validate` function in code. The reusable `useForm` hook holds the values, works out the errors on every render,
remembers which fields were touched, and exposes `isValid` for the submit button.

**Validation messages** appear once the user has typed in or left a field. **Submit buttons** are disabled while
the form is invalid and while the request is running (no double submits), and show a spinner.

**Field rules (Milestone 1)**
- Email: required, `name@domain.tld`.
- Password: 8-64 characters with an upper-case letter, a lower-case letter, a number and a special character.
  The backend checks the same pattern on sign-up.
- Profile image (sign-up): optional. When given it must be `http(s)://...` ending in `.png .jpg .jpeg .gif .webp .svg`,
  and a preview is shown; without one (or if the image cannot load) the app shows the user's initials.
- Username: required, unique, 3-30 letters/numbers/dot/underscore/hyphen (stored in lower case by the backend).
  Name: required, at most 100 characters, and may be the same as another user's name. Role: required.
- Because names may repeat, drop-downs and filters show users as "Name (@username)", and the sidebar shows the
  @username under the name.

**Login and the role drop-down.** Our backend's login checks email + password and returns the user, including the
role. The app then compares that role with the one picked in the drop-down. If they differ, the login is refused
with a clear message. The role used for redirects and page guards always comes from the server, never from the
drop-down.

**Session.** After login, the user's public data (no password - the backend never returns it) is kept in React
context and in `sessionStorage`, so a page refresh keeps you logged in and closing the tab logs you out. Data read
back from storage is checked with a type guard before it is trusted. The backend has no tokens (JWT), so this is
a frontend session; securing every API call with tokens would be the next step.

**Route guards.** Owner pages only open for Project Owners and assignee pages only for Assignees; anyone else is
redirected. Login/Signup redirect a logged-in user to their dashboard.

**Errors.** Components never call Axios directly; they call `userService` (and later `projectService`,
`issueService`). `getErrorMessage` turns any failure into one sentence: the backend's own message
(e.g. *Invalid email or password*, *A user with email ... already exists*), the field messages of a 400,
a "service unavailable" text for 502/503, a timeout text, or "cannot reach the server" when the gateway is down.

**Owner pages share one layout (Milestone 2).** `OwnerLayout` is a layout route: it shows the sidebar and loads
what several owner pages need - the owner's projects, all users and the number of issues the owner created - with
three requests sent at the same time (`Promise.all`). The pages receive it through React Router's Outlet context
(`useOwnerData()`), so the same data is not fetched on every page, and `reload()` refreshes it after a create.

**Dashboard (Milestone 2)**
- The first project from the API is selected by default. The selected project is kept in the URL
  (`/owner/dashboard?projectId=2`), so refresh, Back and links from other pages keep the same project.
- The project's issues are loaded by `ProjectIssues`, which the page renders with `key={projectId}`: a new project
  means a fresh component, so its issues, loading state and filters always start clean.
- Search, assignee filter and priority filter all run in the browser (case study: "filtering must be done on
  Front-end itself"). The search text is a **regular expression**, ignoring case, matched against summary and
  description (`^add`, `login|password`); an unfinished pattern such as `[` is matched as plain text instead of
  crashing, with a small hint.
- The assignee filter lists the project's team: everyone who has an issue in the project.
- Data loads use an `ignore` flag in the effect's clean-up, so an old, slower answer can never overwrite newer data.
- Dates are shown as dd-mm-yyyy by cutting the ISO text apart, not with `new Date()`, which can shift a date by a day
  in some time zones.

**Create Project (Milestone 3)**
- Project Name: required, at most 150 characters, letters/numbers/spaces and only `- / | .` (same pattern as the
  backend). Start and End Date: date pickers; the end date cannot be before the start date (the picker also starts
  at the start date).
- Project Owner: the drop-down of Project Owners from the API, **locked to the logged-in owner**. A project only shows
  on its owner's dashboard, so creating one for another owner would make it disappear for you at once (and hand work
  to someone without asking). The owner sent to the API is taken from the logged-in user, not from the form. (The API
  itself would still accept another owner id - it has no login token to know who is calling; JWT would close that.)
- CREATE is enabled only for a valid form and disabled while saving; RESET blanks the name and dates (the owner
  stays you). Server errors (e.g. *A project named 'X' already exists*) are shown above the form and the typed values
  are kept.
- On success the page waits for `reload()` (sidebar count and project list), then opens the new project's board
  with a green one-time message passed in the router state.

**Create Issue (Milestone 4)**
- The fields, limits, validation and the conversion to API types live in `pages/owner/issueForm.ts`, and the input
  fields in `IssueFormFields.tsx`. The Edit Issue form (Milestone 5) reuses both, so the two forms always apply the
  same rules.
- Where the case study's Create screen and Edit table disagree, one rule is used for both:
  - Summary: required, 5-100 characters, letters/numbers/spaces and only `- / | .` (the backend checks the same).
  - Description: optional, but 10-500 characters when filled in (with a live counter).
  - Sprint: required whole number from 1 to 999. Story Point: required **prime** number up to 100
    (the backend accepts 0-100; "prime only" is a screen rule).
  - Type, Project, Priority, Assignee and Status: required drop-downs. Project lists your own projects;
    Assignee lists every user with the Assignee role.
  - Tags: optional, at most 100 characters, typed as `#delivery #feature` or `delivery, feature`; sent to the
    backend as `delivery,feature` (see `utils/tagUtils.ts`).
- `toIssueApiFields` turns the form's text into typed values (numbers, enum unions checked with type guards,
  empty optional text as `null`); `createdBy` is the logged-in owner.
- On success the sidebar count is refreshed and the issue's project board opens with a success message.
  An owner without projects sees a "create a project first" hint instead of the form.

**Issue Details and Edit Issue (Milestone 5)**
- Clicking a card opens `/owner/issues/:issueId`. The card's title is a link with Bootstrap's `stretched-link`,
  so the whole card is clickable. The page shows the breadcrumb (*Project Board* goes back to that project's board),
  the title, description, project, type, priority, sprint, story points, tags as chips, status, assignee,
  created date (dd-mm-yyyy) and last-updated date and time (dd-mm-yyyy | HH:mm).
- `useIssue(id)` loads one issue. Each answer is stored with the id it belongs to, so when the id in the URL
  changes the old issue is never shown under the new id; ids such as `abc` are not even requested.
- An owner can only open and edit issues of the projects they own.
- **Edit Issue** reuses `issueForm.ts` and `IssueFormFields` from Create Issue, pre-filled with the issue's values.
  The form is only rendered after the issue has loaded, so `useForm` starts from those values and **RESET** goes back
  to them (the case study's "initial state"). EDIT is enabled only while every required field is valid.
- The update is a PUT with every field; a cleared description or tag list is sent as `""`, which the backend reads
  as "clear it" (a missing field would mean "leave it unchanged"). Moving an issue to another project is allowed;
  the backend checks that the project exists.
- After saving, the Issue Details page opens with a success message.

**Assignee pages (Milestone 6)**
- `AssigneeLayout` shows the sidebar (photo, name, email, *Issues Assigned*, Logout - no navigation links, as in the
  case study) and loads the Assignee's issues with `GET /api/users/{id}/issues` (the User Service asks the Issue
  Service through Feign, so this request crosses two microservices) plus all projects for the project names.
- The dashboard reuses the owner's board components and the RegEx search; a card opens `/assignee/issues/:issueId`.
- The details page reuses `IssueDetailsView`, with *Issue Dashboard* in the breadcrumb and `StatusUpdateForm` instead
  of the Edit button: a status drop-down that starts at the current status; **Save Updates** is enabled only when a
  different status is chosen. Saving sends just `{ "status": "TESTING" }` (the backend's PUT is a partial update), shows
  the server's copy of the issue, and refreshes the board and the sidebar count.
- An Assignee can only open issues assigned to them; owners and assignees cannot open each other's pages.

**Back-end API integration (Milestone 7)**
- Every screen talks to the real microservices through the gateway. Components never call Axios: they call the
  service files, which return typed models (`models/`) that copy the backend's DTOs field by field.
- The case study lists its endpoints as `/api/v1/...`; our Week 3 backend uses `/api/...` (same operations).

| Screen / action                  | Service function                      | Endpoint (through the gateway, port 8080) |
|----------------------------------|---------------------------------------|-------------------------------------------|
| Login                            | `userService.login`                   | `POST /api/users/login`                   |
| Signup                           | `userService.signUp`                  | `POST /api/users`                         |
| Owner layout (sidebar, lists)    | `projectService.getProjectsByOwner`, `userService.getAllUsers`, `issueService.getIssuesByOwner` | `GET /api/projects/owner/{ownerId}`, `GET /api/users`, `GET /api/issues/owner/{ownerId}` |
| Owner dashboard board            | `issueService.getIssuesByProject`     | `GET /api/issues/project/{projectId}`     |
| Create Project                   | `projectService.createProject`        | `POST /api/projects`                      |
| Create Issue                     | `issueService.createIssue`            | `POST /api/issues`                        |
| Issue Details (both roles)       | `issueService.getIssueById`           | `GET /api/issues/{id}`                    |
| Edit Issue / assignee status     | `issueService.updateIssue`            | `PUT /api/issues/{id}`                    |
| Assignee layout                  | `userService.getIssuesAssignedToUser`, `projectService.getAllProjects` | `GET /api/users/{userId}/issues` (User Service -> Issue Service by Feign), `GET /api/projects` |

- Listed in the case study but not needed by any screen (so no service function was written for them): get one
  user/project by id, update/delete project, all issues, issues by assignee id (the assignee screen uses
  `/users/{id}/issues`, which the case study names), issues by project name, `/projects/{id}/issues` (the board calls
  the Issue Service directly - one network hop fewer) and `/projects/{id}/insights` (no screen shows insights).
- **Checked against the real backend** (11 Oct 2026): every GET answer matched the TypeScript models exactly
  (field names, types, enum values, null where allowed); create/duplicate/role checks/edit/clear/status-only flows
  gave the expected answers; every service error carried the `{ status, error, message, path, fieldErrors }` shape
  that `getErrorMessage` reads. Typical answer time 15-25 ms (about 250 ms for the first Feign call).
- Errors made by the gateway itself (a service stopped: 503, or 500/504) have no `message`, so `getErrorMessage`
  uses a fixed sentence for those statuses.
- CORS: the gateway allows `http://localhost:5173` (`npm run dev`) and `http://localhost:4173` (`npm run preview`,
  the production build). Opening the app as `127.0.0.1` instead of `localhost` is a different origin and is refused.

**Name and look.** The app is called **InfinityCastle - Issue Tracker** (one constant in `appConfig.ts`), with no company branding. Its own "Coral Notebook" theme lives in `index.css`: charcoal sidebar, coral accent, cream background, serif headings, one colour per board column, an "IC" logo mark, a time-of-day greeting in the header and a small credit line in the sidebar. Bootstrap's `btn-warning` / `btn-outline-warning` are re-coloured through Bootstrap's own CSS variables, so no component had to change for the colours.
