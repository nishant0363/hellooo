package com.issuetracker.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * API Gateway of the Issue Tracking System (port 8080) - the single entry point for every client.
 *
 * A client sends every request to http://localhost:8080. The gateway looks at the path, picks the
 * microservice that owns it (see GatewayConfig), finds a running instance of that service in Eureka
 * and forwards the request. The client never needs to know the ports 8081 / 8082 / 8083.
 */
@SpringBootApplication
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
