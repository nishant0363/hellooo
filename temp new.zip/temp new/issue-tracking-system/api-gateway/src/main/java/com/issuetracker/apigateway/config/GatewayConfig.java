package com.issuetracker.apigateway.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsWebFilter;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

/**
 * Routes and CORS settings of the API Gateway.
 */
@Configuration
public class GatewayConfig {

    /**
     * The routing table: "requests whose path matches X go to service Y".
     *
     * uri("lb://user-service"):
     *   lb:// = "load-balanced". The gateway asks Eureka for all running instances of user-service and
     *   Spring Cloud LoadBalancer picks one (round robin). This is CLIENT-SIDE load balancing: the gateway
     *   itself chooses the instance, instead of a separate load-balancer machine sitting in front of the services.
     *
     * The paths are not changed on the way: GET http://localhost:8080/api/users/1 is forwarded as
     * GET /api/users/1 to one instance of the User Service.
     */
    @Bean
    public RouteLocator issueTrackerRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("user-service", route -> route
                        .path("/api/users/**")
                        .uri("lb://user-service"))
                .route("project-service", route -> route
                        .path("/api/projects/**")
                        .uri("lb://project-service"))
                .route("issue-service", route -> route
                        .path("/api/issues/**")
                        .uri("lb://issue-service"))
                .build();
    }

    /**
     * CORS (Cross-Origin Resource Sharing).
     *
     * Browsers block a page from calling a DIFFERENT origin (scheme + host + port) unless that origin allows it.
     * Each service's Swagger page (e.g. http://localhost:8083/swagger-ui.html) can send its requests
     * "Through the API Gateway" (http://localhost:8080) - a different port, so a different origin.
     * This filter tells the browser those Swagger pages (and a local React app, for next week) may call the gateway.
     *
     * Only the gateway sets CORS headers; the services behind it do not, so the browser never sees them twice.
     *
     * The allowed origins come from the property app.cors.allowed-origins (comma-separated, Spring turns it
     * into a String[]): the localhost addresses in application.properties on the laptop, and the S3 website
     * address (FRONTEND_ORIGIN) in application-aws.properties on AWS - no code change between environments.
     */
    @Bean
    public CorsWebFilter corsWebFilter(@Value("${app.cors.allowed-origins}") String[] allowedOrigins) {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(allowedOrigins));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setMaxAge(3600L);   // the browser may remember this answer for an hour

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return new CorsWebFilter(source);
    }
}
