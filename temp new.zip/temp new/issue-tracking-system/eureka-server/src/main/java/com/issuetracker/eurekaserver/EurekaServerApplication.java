package com.issuetracker.eurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Service registry of the Issue Tracking System (port 8761).
 *
 * How service discovery works:
 *  1. Each microservice starts and REGISTERS with Eureka: "I am issue-service, I am at localhost:8083".
 *  2. It then sends a HEARTBEAT every 30 seconds. If heartbeats stop, Eureka removes the instance.
 *  3. When one service wants to call another, it asks Eureka for the current address of that service NAME,
 *     so no service ever hard-codes another service's host and port.
 *
 * @EnableEurekaServer turns this Spring Boot application into that registry.
 * Dashboard: http://localhost:8761
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}
