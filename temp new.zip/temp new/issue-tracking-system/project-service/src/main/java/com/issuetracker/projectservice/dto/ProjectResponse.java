package com.issuetracker.projectservice.dto;

import java.time.LocalDate;

import com.issuetracker.projectservice.entity.Project;

/**
 * What the API sends back for a project. Keeping a separate response class (instead of returning the
 * entity) means the database structure can change without changing the API that clients depend on.
 */
public record ProjectResponse(
        Integer projectId,
        String projectName,
        Integer projectOwnerId,
        LocalDate startDate,
        LocalDate endDate) {

    /** Converts a database entity into the response shape. */
    public static ProjectResponse from(Project project) {
        return new ProjectResponse(
                project.getId(),
                project.getProjectName(),
                project.getProjectOwnerId(),
                project.getStartDate(),
                project.getEndDate());
    }
}
