package com.issuetracker.projectservice.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * JSON body of POST /api/projects (create) and PUT /api/projects/{projectId} (update).
 * Inputs from the case study: project name, product owner ID, start date and end date.
 *
 * Dates are written as "yyyy-MM-dd" in JSON, e.g. "2026-10-01".
 * The rule "end date must not be before start date" involves TWO fields, so it is checked
 * in the service layer rather than with an annotation on one field.
 *
 * Week 4: the project name follows the React case study - at most 150 characters, and the only special
 * characters allowed are - / | . (the React form checks the same rule).
 */
public record ProjectRequest(

        @Schema(example = "Payments Gateway", description = "Up to 150 characters: letters, numbers, spaces and - / | .")
        @NotBlank(message = "Project name is required")
        @Size(max = 150, message = "Project name must be at most 150 characters")
        @Pattern(regexp = "^[A-Za-z0-9 ./|-]+$",
                message = "Project name can only contain letters, numbers, spaces and - / | .")
        String projectName,

        @Schema(example = "1", description = "User id of the project owner (must be a PROJECT_OWNER)")
        @NotNull(message = "Project owner id is required")
        @Positive(message = "Project owner id must be a positive number")
        Integer projectOwnerId,

        @Schema(example = "2026-10-05")
        @NotNull(message = "Start date is required (format yyyy-MM-dd)")
        LocalDate startDate,

        @Schema(example = "2027-01-31", description = "Optional. Must not be before the start date")
        LocalDate endDate) {
}
