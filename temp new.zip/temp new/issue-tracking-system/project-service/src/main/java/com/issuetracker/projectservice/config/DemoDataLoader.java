package com.issuetracker.projectservice.config;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.issuetracker.projectservice.entity.Project;
import com.issuetracker.projectservice.repository.ProjectRepository;

/**
 * Adds a few demo projects the first time the service starts (only when the project table is EMPTY,
 * so restarting never creates duplicates).
 *
 * The rows are saved straight through the repository (not through ProjectService), so start-up never
 * depends on another service being up - from Milestone 5 the service checks owners with the User Service.
 *
 * Owners are the demo users of the User Service: 1 = Priya Sharma, 2 = Karan Mehta (both PROJECT_OWNER).
 * On a fresh database the projects get ids 1-3 (the Issue Service's demo data relies on that):
 *   1 Customer Portal     - owner 1
 *   2 Mobile Banking App  - owner 1
 *   3 Inventory Revamp    - owner 2
 */
@Component
public class DemoDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoDataLoader.class);

    private final ProjectRepository projectRepository;

    @Autowired
    public DemoDataLoader(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Override
    public void run(String... args) {
        if (projectRepository.count() > 0) {
            log.info("Projects already exist - demo data not loaded");
            return;
        }

        projectRepository.save(newProject("Customer Portal", 1, LocalDate.of(2026, 9, 1), LocalDate.of(2026, 12, 31)));
        projectRepository.save(newProject("Mobile Banking App", 1, LocalDate.of(2026, 10, 1), LocalDate.of(2027, 3, 31)));
        projectRepository.save(newProject("Inventory Revamp", 2, LocalDate.of(2026, 8, 15), LocalDate.of(2026, 11, 30)));

        log.info("Demo projects loaded (3 projects)");
    }

    private Project newProject(String name, Integer ownerId, LocalDate start, LocalDate end) {
        Project project = new Project();
        project.setProjectName(name);
        project.setProjectOwnerId(ownerId);
        project.setStartDate(start);
        project.setEndDate(end);
        return project;
    }
}
