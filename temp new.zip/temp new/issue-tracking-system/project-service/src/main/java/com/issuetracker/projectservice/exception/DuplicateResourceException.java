package com.issuetracker.projectservice.exception;

/**
 * Thrown when a new record would clash with an existing one (e.g. a project name that is already used).
 * GlobalExceptionHandler turns it into 409 Conflict.
 */
public class DuplicateResourceException extends RuntimeException {

    public DuplicateResourceException(String message) {
        super(message);
    }
}
