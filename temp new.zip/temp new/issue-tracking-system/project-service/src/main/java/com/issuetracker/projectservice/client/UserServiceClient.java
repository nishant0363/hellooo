package com.issuetracker.projectservice.client;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.issuetracker.projectservice.exception.ServiceUnavailableException;

/**
 * Calls the User Service with RestTemplate (Milestone 5 - the "RestTemplate" arrow in the architecture diagram).
 *
 * RestTemplate vs Feign (IssueClient):
 *  - With RestTemplate WE build the URL and make the call ourselves (getForObject ...).
 *  - With Feign we only declare an interface and Spring generates the call.
 * Both find the other service through Eureka: the URL uses the service NAME "user-service" instead of
 * localhost:8081, and the @LoadBalanced RestTemplate bean (see AppConfig) swaps the name for a real
 * address of a running instance.
 */
@Component
public class UserServiceClient {

    private static final Logger log = LoggerFactory.getLogger(UserServiceClient.class);

    /** "user-service" is the User Service's spring.application.name, resolved through Eureka. */
    private static final String USER_BY_ID_URL = "http://user-service/api/users/{userId}";

    private final RestTemplate restTemplate;

    @Autowired
    public UserServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * Looks a user up in the User Service.
     *
     * @return the user, or Optional.empty() if the User Service answers 404 (no such user)
     * @throws ServiceUnavailableException if the User Service cannot be reached
     */
    public Optional<UserDto> findUserById(Integer userId) {
        try {
            UserDto user = restTemplate.getForObject(USER_BY_ID_URL, UserDto.class, userId);
            return Optional.ofNullable(user);
        } catch (HttpClientErrorException.NotFound ex) {
            return Optional.empty();
        } catch (RestClientException | IllegalStateException ex) {
            // RestClientException: connection refused, timeout or a 5xx answer.
            // IllegalStateException: the load balancer found no running "user-service" in Eureka.
            log.error("Call to user-service failed: {}", ex.getMessage());
            throw new ServiceUnavailableException("user-service");
        }
    }
}
