package com.issuetracker.issueservice.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

/**
 * JPA entity = one row of the "issue" table in issue_db. Columns follow the DB design from the case study:
 * id, summary, description, project, assignee, created_by, priority, status, type, sprint, story_point,
 * tags, created_on, last_updated.
 *
 * project, assignee and created_by hold ids that live in OTHER services' databases (project_db, user_db),
 * so they are plain INT columns with no foreign keys. From Milestone 5 the service checks them by calling
 * the Project and User services before saving.
 *
 * Spring Boot maps Java camelCase names to snake_case columns automatically
 * (createdBy -> created_by, storyPoint -> story_point ...). @Column(name = ...) is only needed where the
 * Java name differs from the column name (projectId -> project, assigneeId -> assignee).
 */
@Entity
@Table(name = "issue")
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String summary;

    /** Up to 500 characters (the case study's limit), so the column is VARCHAR(500) instead of the default 255. */
    @Column(length = 500)
    private String description;

    /** Id of the project this issue belongs to (project_db). */
    @Column(name = "project", nullable = false)
    private Integer projectId;

    /** Id of the user (an ASSIGNEE) who works on the issue (user_db). */
    @Column(name = "assignee", nullable = false)
    private Integer assigneeId;

    /** Id of the user (a PROJECT_OWNER) who created the issue - the issue's "owner". */
    @Column(nullable = false)
    private Integer createdBy;

    /** EnumType.STRING stores the NAME ("HIGH"), so re-ordering the enum can never corrupt data. */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueStatus status;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueType type;

    /** Sprint number (1, 2, 3 ...) in which the issue is planned. Optional in the API. */
    private Integer sprint;

    /** Effort estimate. 0 when not estimated yet. */
    @Column(nullable = false)
    private Integer storyPoint;

    /** Comma-separated labels, e.g. "backend,login". Optional. */
    private String tags;

    /** Set by the server when the issue is first saved - never taken from the client. */
    @Column(nullable = false, updatable = false)
    private LocalDate createdOn;

    /**
     * Set by the server every time the issue is changed.
     * A date AND time (the Issue Details screen shows "10-06-2025 | 05:30"), so LocalDateTime.
     */
    @Column(nullable = false)
    private LocalDateTime lastUpdated;

    /** JPA needs a no-argument constructor to create objects from database rows. */
    public Issue() {
    }

    // ---------- JPA life-cycle callbacks ----------

    /** Runs automatically just BEFORE the first INSERT of this issue. */
    @PrePersist
    void onCreate() {
        this.createdOn = LocalDate.now();
        this.lastUpdated = nowToTheSecond();
    }

    /** Runs automatically just BEFORE every UPDATE of this issue. */
    @PreUpdate
    void onUpdate() {
        this.lastUpdated = nowToTheSecond();
    }

    /** The current date and time without fractions of a second, e.g. 2026-10-11T14:05:33 (cleaner JSON). */
    private static LocalDateTime nowToTheSecond() {
        return LocalDateTime.now().withNano(0);
    }

    // ---------- getters and setters ----------

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getAssigneeId() {
        return assigneeId;
    }

    public void setAssigneeId(Integer assigneeId) {
        this.assigneeId = assigneeId;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public IssueStatus getStatus() {
        return status;
    }

    public void setStatus(IssueStatus status) {
        this.status = status;
    }

    public IssueType getType() {
        return type;
    }

    public void setType(IssueType type) {
        this.type = type;
    }

    public Integer getSprint() {
        return sprint;
    }

    public void setSprint(Integer sprint) {
        this.sprint = sprint;
    }

    public Integer getStoryPoint() {
        return storyPoint;
    }

    public void setStoryPoint(Integer storyPoint) {
        this.storyPoint = storyPoint;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public LocalDate getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDate createdOn) {
        this.createdOn = createdOn;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
