package com.issuetracker.issueservice.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The part of the Project Service's ProjectResponse JSON that this service needs (to check a project exists).
 * Other fields (dates ...) are ignored.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ProjectDto(
        Integer projectId,
        String projectName,
        Integer projectOwnerId) {
}
