package com.issuetracker.issueservice.dto;

/**
 * A plain confirmation message, e.g. {"message": "Issue 6 deleted successfully"}.
 * Used by DELETE, where there is no object left to return.
 */
public record MessageResponse(String message) {
}
