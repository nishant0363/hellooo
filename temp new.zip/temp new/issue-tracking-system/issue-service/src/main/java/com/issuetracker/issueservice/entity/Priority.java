package com.issuetracker.issueservice.entity;

/**
 * How urgent an issue is. Stored as text in a MySQL ENUM column (see Issue.priority).
 *
 * Week 4: the values follow the case study's "Object Value Mapping" (1 LOW, 2 MEDIUM, 3 HIGH).
 */
public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
