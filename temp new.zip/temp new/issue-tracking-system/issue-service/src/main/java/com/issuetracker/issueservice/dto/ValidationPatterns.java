package com.issuetracker.issueservice.dto;

/**
 * Regular expressions shared by CreateIssueRequest and UpdateIssueRequest.
 *
 * Annotation values must be compile-time constants, so the pattern and its message live here as
 * static final Strings and both records refer to them - one place to change the rule.
 * The React form uses the same rule, so the browser and the server always agree.
 */
public final class ValidationPatterns {

    /** Letters, digits, spaces and only these special characters: - / | . (case study rule for the summary). */
    public static final String SUMMARY = "^[A-Za-z0-9 ./|-]+$";

    public static final String SUMMARY_MESSAGE = "Summary can only contain letters, numbers, spaces and - / | .";

    /** Only constants here - nobody needs an object of this class. */
    private ValidationPatterns() {
    }
}
