package com.issuetracker.issueservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.issuetracker.issueservice.dto.CreateIssueRequest;
import com.issuetracker.issueservice.dto.IssueResponse;
import com.issuetracker.issueservice.dto.IssueSavedResponse;
import com.issuetracker.issueservice.dto.MessageResponse;
import com.issuetracker.issueservice.dto.UpdateIssueRequest;
import com.issuetracker.issueservice.service.IssueService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/**
 * REST endpoints of the Issue Service (section 7.3 of the case study, plus DELETE which the
 * objective mentions but the endpoint table leaves out).
 *
 * The /project, /owner and /assignee endpoints are the ones other services call in Milestone 5
 * ("inter service communication"). Here they are ordinary queries on this service's own database.
 */
@RestController
@RequestMapping("/api/issues")
@Tag(name = "Issue Service", description = "Create, read, update and delete issues")
public class IssueController {

    private final IssueService issueService;

    @Autowired
    public IssueController(IssueService issueService) {
        this.issueService = issueService;
    }

    /** GET /api/issues -> 200 OK with every issue. */
    @Operation(summary = "Retrieve a list of all issues")
    @GetMapping
    public ResponseEntity<List<IssueResponse>> getAllIssues() {
        return ResponseEntity.ok(issueService.getAllIssues());
    }

    /** POST /api/issues -> 201 Created with the new issue (incl. its id). 400 if the input is invalid. */
    @Operation(summary = "Create a new issue")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)   // only tells Swagger the success code is 201; ResponseEntity sets it
    public ResponseEntity<IssueSavedResponse> createIssue(@Valid @RequestBody CreateIssueRequest request) {
        IssueResponse created = issueService.createIssue(request);
        IssueSavedResponse body = new IssueSavedResponse(
                "Issue created successfully with id " + created.issueId(), created);
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    /** GET /api/issues/{id} -> 200 OK, or 404. */
    @Operation(summary = "Retrieve details of a specific issue by issue ID")
    @GetMapping("/{id}")
    public ResponseEntity<IssueResponse> getIssueById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(issueService.getIssueById(id));
    }

    /**
     * PUT /api/issues/{id} -> 200 OK with the updated issue. Only the fields sent are changed.
     *
     * The swagger @RequestBody annotation (full name used because Spring also has a @RequestBody) only adds
     * two ready-made examples to Swagger UI; Spring's @RequestBody is what actually reads the JSON.
     */
    @Operation(summary = "Update details of a specific issue by issue ID (only the fields sent are changed)")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Send only the fields to change",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = UpdateIssueRequest.class),
                    examples = {
                            @ExampleObject(name = "Assignee updates the status",
                                    value = "{\"status\": \"DEVELOPMENT\"}"),
                            @ExampleObject(name = "Owner reassigns and changes priority",
                                    value = "{\"assigneeId\": 4, \"priority\": \"HIGH\"}")
                    }))
    @PutMapping("/{id}")
    public ResponseEntity<IssueSavedResponse> updateIssue(@PathVariable("id") Integer id,
            @Valid @RequestBody UpdateIssueRequest request) {
        IssueResponse updated = issueService.updateIssue(id, request);
        return ResponseEntity.ok(new IssueSavedResponse("Issue updated successfully", updated));
    }

    /** DELETE /api/issues/{id} -> 200 OK with a message, or 404. */
    @Operation(summary = "Delete a specific issue by issue ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<MessageResponse> deleteIssue(@PathVariable("id") Integer id) {
        issueService.deleteIssue(id);
        return ResponseEntity.ok(new MessageResponse("Issue " + id + " deleted successfully"));
    }

    /** GET /api/issues/project/{projectId} -> 200 OK (empty list if the project has no issues). */
    @Operation(summary = "Retrieve issues within a specific project by project ID (inter-service)")
    @GetMapping("/project/{projectId}")
    public ResponseEntity<List<IssueResponse>> getIssuesByProject(@PathVariable("projectId") Integer projectId) {
        return ResponseEntity.ok(issueService.getIssuesByProject(projectId));
    }

    /** GET /api/issues/owner/{ownerId} -> 200 OK with the issues this user created. */
    @Operation(summary = "Retrieve issues owned (created) by a specific user by owner ID (inter-service)")
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<IssueResponse>> getIssuesByOwner(@PathVariable("ownerId") Integer ownerId) {
        return ResponseEntity.ok(issueService.getIssuesByOwner(ownerId));
    }

    /** GET /api/issues/assignee/{assigneeId} -> 200 OK with the issues assigned to this user. */
    @Operation(summary = "Retrieve issues assigned to a specific user by assignee ID (inter-service)")
    @GetMapping("/assignee/{assigneeId}")
    public ResponseEntity<List<IssueResponse>> getIssuesByAssignee(@PathVariable("assigneeId") Integer assigneeId) {
        return ResponseEntity.ok(issueService.getIssuesByAssignee(assigneeId));
    }
}
