package com.issuetracker.issueservice.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import feign.FeignException;

import com.issuetracker.issueservice.client.ProjectClient;
import com.issuetracker.issueservice.client.UserClient;
import com.issuetracker.issueservice.client.UserDto;
import com.issuetracker.issueservice.dto.CreateIssueRequest;
import com.issuetracker.issueservice.dto.IssueResponse;
import com.issuetracker.issueservice.dto.UpdateIssueRequest;
import com.issuetracker.issueservice.entity.Issue;
import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.exception.InvalidRequestException;
import com.issuetracker.issueservice.exception.ResourceNotFoundException;
import com.issuetracker.issueservice.repository.IssueRepository;
import com.issuetracker.issueservice.service.IssueService;

/**
 * Business logic for issues.
 *
 * Rules:
 *  - required fields are checked by @Valid in the controller (summary, project, assignee, creator, priority, type)
 *  - status defaults to TO_DO and story points to 0 when not given
 *  - tags are tidied up: "Backend,  login ," is stored as "backend,login"
 *  - created/last-updated dates are set automatically (see @PrePersist / @PreUpdate in Issue)
 *  - update changes only the fields that were sent; an empty update is rejected
 *  - Week 4: update may move the issue to another project (the Edit Issue screen has a Project field)
 *  - Milestone 5: before saving, the project must exist (Project Service), the creator must be a
 *    PROJECT_OWNER and the assignee an ASSIGNEE (User Service) - both asked with Feign clients.
 *    There are no foreign keys between the databases, so these calls are how references are kept valid.
 *
 * createIssue and updateIssue are not @Transactional: a database transaction should not stay open while
 * waiting for another service to answer. Each repository call still runs in its own transaction.
 */
@Service
public class IssueServiceImpl implements IssueService {

    private static final Logger log = LoggerFactory.getLogger(IssueServiceImpl.class);

    private final IssueRepository issueRepository;
    private final UserClient userClient;         // Feign -> User Service
    private final ProjectClient projectClient;   // Feign -> Project Service

    @Autowired
    public IssueServiceImpl(IssueRepository issueRepository, UserClient userClient, ProjectClient projectClient) {
        this.issueRepository = issueRepository;
        this.userClient = userClient;
        this.projectClient = projectClient;
    }

    @Override
    public IssueResponse createIssue(CreateIssueRequest request) {
        // Milestone 5: check the ids that point into other services' databases
        checkProjectExists(request.projectId());
        checkUserHasRole(request.createdBy(), UserDto.PROJECT_OWNER, "createdBy");
        checkUserHasRole(request.assigneeId(), UserDto.ASSIGNEE, "assigneeId");

        Issue issue = new Issue();
        issue.setSummary(request.summary().trim());
        issue.setDescription(blankToNull(request.description()));
        issue.setProjectId(request.projectId());
        issue.setAssigneeId(request.assigneeId());
        issue.setCreatedBy(request.createdBy());
        issue.setPriority(request.priority());
        issue.setType(request.type());
        // Defaults for the optional fields
        issue.setStatus(request.status() != null ? request.status() : IssueStatus.TO_DO);
        issue.setStoryPoint(request.storyPoint() != null ? request.storyPoint() : 0);
        issue.setSprint(request.sprint());   // a number, or null when not planned yet
        issue.setTags(normalizeTags(request.tags()));

        Issue saved = issueRepository.save(issue);
        log.info("Issue created: id={}, project={}, assignee={}", saved.getId(), saved.getProjectId(),
                saved.getAssigneeId());
        return IssueResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponse> getAllIssues() {
        List<IssueResponse> issues = toResponses(issueRepository.findAll());
        // Milestone 7 load-balancing demo: with two Issue Service instances running, repeated
        // GET http://localhost:8080/api/issues calls print this line in the two consoles in turn
        log.info("GET /api/issues handled by this instance - returning {} issues", issues.size());
        return issues;
    }

    @Override
    @Transactional(readOnly = true)
    public IssueResponse getIssueById(Integer issueId) {
        return IssueResponse.from(findIssueOrThrow(issueId));
    }

    @Override
    public IssueResponse updateIssue(Integer issueId, UpdateIssueRequest request) {
        if (request.hasNoChanges()) {
            throw new InvalidRequestException("Send at least one field to update");
        }
        Issue issue = findIssueOrThrow(issueId);

        // Partial update: a field that is null in the request means "leave it as it is"
        if (request.summary() != null) {
            String summary = request.summary().trim();
            if (summary.isEmpty()) {
                throw new InvalidRequestException("Summary cannot be blank");
            }
            issue.setSummary(summary);
        }
        if (request.description() != null) {
            issue.setDescription(blankToNull(request.description()));   // "" clears it
        }
        if (request.projectId() != null) {
            // Week 4: only ask the Project Service when the project really changes
            if (!request.projectId().equals(issue.getProjectId())) {
                checkProjectExists(request.projectId());
            }
            issue.setProjectId(request.projectId());
        }
        if (request.assigneeId() != null) {
            // Milestone 5: only ask the User Service when the assignee really changes
            if (!request.assigneeId().equals(issue.getAssigneeId())) {
                checkUserHasRole(request.assigneeId(), UserDto.ASSIGNEE, "assigneeId");
            }
            issue.setAssigneeId(request.assigneeId());
        }
        if (request.priority() != null) {
            issue.setPriority(request.priority());
        }
        if (request.status() != null) {
            issue.setStatus(request.status());
        }
        if (request.type() != null) {
            issue.setType(request.type());
        }
        if (request.sprint() != null) {
            issue.setSprint(request.sprint());
        }
        if (request.storyPoint() != null) {
            issue.setStoryPoint(request.storyPoint());
        }
        if (request.tags() != null) {
            issue.setTags(normalizeTags(request.tags()));
        }

        // saveAndFlush writes the UPDATE now, so @PreUpdate has already set lastUpdated in the response
        Issue saved = issueRepository.saveAndFlush(issue);
        log.info("Issue updated: id={}, status={}", saved.getId(), saved.getStatus());
        return IssueResponse.from(saved);
    }

    @Override
    @Transactional
    public void deleteIssue(Integer issueId) {
        if (!issueRepository.existsById(issueId)) {
            throw new ResourceNotFoundException("Issue not found with id " + issueId);
        }
        issueRepository.deleteById(issueId);
        log.info("Issue deleted: id={}", issueId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponse> getIssuesByProject(Integer projectId) {
        return toResponses(issueRepository.findByProjectId(projectId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponse> getIssuesByOwner(Integer ownerId) {
        return toResponses(issueRepository.findByCreatedBy(ownerId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponse> getIssuesByAssignee(Integer assigneeId) {
        return toResponses(issueRepository.findByAssigneeId(assigneeId));
    }

    // ---------- Milestone 5: checks against other services ----------

    /** Asks the Project Service whether the project exists. Its 404 becomes our 400 (bad id in the body). */
    private void checkProjectExists(Integer projectId) {
        try {
            projectClient.getProjectById(projectId);
        } catch (FeignException.NotFound ex) {
            throw new InvalidRequestException("projectId: no project exists with id " + projectId);
        }
    }

    /**
     * Asks the User Service for the user and checks the role.
     * Any other failure (User Service down ...) is not caught here: the FeignException goes on to
     * GlobalExceptionHandler, which answers 503 - and the issue is not saved.
     */
    private void checkUserHasRole(Integer userId, String requiredRole, String fieldName) {
        UserDto user;
        try {
            user = userClient.getUserById(userId);
        } catch (FeignException.NotFound ex) {
            throw new InvalidRequestException(fieldName + ": no user exists with id " + userId);
        }
        if (!requiredRole.equals(user.role())) {
            throw new InvalidRequestException(fieldName + ": user " + userId + " (" + user.name() + ") is "
                    + user.role() + ", but must be " + requiredRole);
        }
    }

    // ---------- helpers ----------

    private Issue findIssueOrThrow(Integer issueId) {
        return issueRepository.findById(issueId)
                .orElseThrow(() -> new ResourceNotFoundException("Issue not found with id " + issueId));
    }

    private List<IssueResponse> toResponses(List<Issue> issues) {
        return issues.stream()
                .map(IssueResponse::from)
                .toList();
    }

    /** Treats "" or "   " the same as "not given", so the database stores NULL instead of empty text. */
    private String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }

    /**
     * Tidies a comma-separated tag list: trims each tag, lower-cases it, drops empty and repeated tags.
     * " Backend, login,,backend " becomes "backend,login". Returns null when no tag is left.
     */
    String normalizeTags(String tags) {
        if (tags == null || tags.isBlank()) {
            return null;
        }
        String cleaned = Arrays.stream(tags.split(","))
                .map(String::trim)
                .map(String::toLowerCase)
                .filter(tag -> !tag.isEmpty())
                .distinct()
                .collect(Collectors.joining(","));
        return cleaned.isEmpty() ? null : cleaned;
    }
}
