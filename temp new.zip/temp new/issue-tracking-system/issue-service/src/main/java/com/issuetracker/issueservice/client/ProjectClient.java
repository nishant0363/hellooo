package com.issuetracker.issueservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client for the Project Service (Milestone 5). Used to check that an issue's project exists
 * before the issue is saved. A 404 from the Project Service becomes FeignException.NotFound.
 */
@FeignClient(name = "project-service")
public interface ProjectClient {

    @GetMapping("/api/projects/{projectId}")
    ProjectDto getProjectById(@PathVariable("projectId") Integer projectId);
}
