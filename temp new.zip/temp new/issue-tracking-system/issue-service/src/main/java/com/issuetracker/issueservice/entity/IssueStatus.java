package com.issuetracker.issueservice.entity;

/**
 * Where an issue is in its life cycle. Stored as text in a MySQL ENUM column (see Issue.status).
 *
 * Week 4: the values now match the four columns of the React board and the case study's
 * "Object Value Mapping" (1 To-Do, 2 Development, 3 Testing, 4 Completed).
 * A new issue starts as TO_DO unless another status is given.
 * (Named IssueStatus rather than Status to avoid confusion with HTTP status codes.)
 */
public enum IssueStatus {
    TO_DO,
    DEVELOPMENT,
    TESTING,
    COMPLETED
}
