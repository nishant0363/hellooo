package com.issuetracker.issueservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Entry point of the Issue microservice (port 8083, database issue_db).
 * It owns all issue data; the User and Project services ask it for issues over HTTP (Milestone 5).
 *
 * @EnableFeignClients (Milestone 5): generate implementations for client.UserClient and client.ProjectClient,
 * which this service uses to validate the project, creator and assignee of an issue.
 */
@SpringBootApplication
@EnableFeignClients
public class IssueServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(IssueServiceApplication.class, args);
    }
}
