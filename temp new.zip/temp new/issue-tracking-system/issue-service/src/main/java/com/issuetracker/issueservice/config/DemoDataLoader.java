package com.issuetracker.issueservice.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.issuetracker.issueservice.entity.Issue;
import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;
import com.issuetracker.issueservice.repository.IssueRepository;

/**
 * Adds demo issues the first time the service starts (only when the issue table is EMPTY).
 * Saved straight through the repository, so start-up never depends on the other services being up.
 *
 * They use the demo users (1, 2 = project owners; 3, 4 = assignees) and demo projects (1, 2, 3)
 * of the User and Project services.
 *
 * Week 4: the data is chosen so the React board has something in every column - project 1
 * (Customer Portal) has one issue in each of TO_DO, DEVELOPMENT, TESTING and COMPLETED - and every
 * value passes the React form rules (story points are prime numbers, sprints are numbers).
 */
@Component
public class DemoDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoDataLoader.class);

    private final IssueRepository issueRepository;

    @Autowired
    public DemoDataLoader(IssueRepository issueRepository) {
        this.issueRepository = issueRepository;
    }

    @Override
    public void run(String... args) {
        if (issueRepository.count() > 0) {
            log.info("Issues already exist - demo data not loaded");
            return;
        }

        // Project 1 - Customer Portal (owner 1). Arguments: project, creator, assignee
        issueRepository.save(newIssue("Login page crashes on wrong password",
                "A stack trace is shown instead of a friendly error message",
                1, 1, 3, Priority.HIGH, IssueStatus.TO_DO, IssueType.BUG, 1, 3, "frontend,login"));
        issueRepository.save(newIssue("Add password reset by email",
                "Send a reset link that stays valid for 30 minutes",
                1, 1, 4, Priority.MEDIUM, IssueStatus.DEVELOPMENT, IssueType.STORY, 1, 5, "backend,email"));
        issueRepository.save(newIssue("Profile page loads slowly",
                "The profile page takes more than five seconds to open",
                1, 1, 3, Priority.MEDIUM, IssueStatus.TESTING, IssueType.BUG, 1, 3, "performance"));
        issueRepository.save(newIssue("Show order history to customers",
                "Customers can see their last twenty orders with status and date",
                1, 1, 4, Priority.HIGH, IssueStatus.COMPLETED, IssueType.STORY, 1, 5, "orders"));
        issueRepository.save(newIssue("Add dark mode toggle",
                "Let users switch between light and dark themes",
                1, 1, 4, Priority.LOW, IssueStatus.TO_DO, IssueType.TASK, 2, 2, "ui"));

        // Project 2 - Mobile Banking App (owner 1)
        issueRepository.save(newIssue("Set up CI pipeline",
                "Build and run the tests on every push",
                2, 1, 3, Priority.LOW, IssueStatus.COMPLETED, IssueType.TASK, 1, 2, "devops"));
        issueRepository.save(newIssue("Fingerprint login on Android",
                "Allow login with the fingerprint sensor on supported phones",
                2, 1, 3, Priority.HIGH, IssueStatus.DEVELOPMENT, IssueType.STORY, 2, 7, "mobile,security"));

        // Project 3 - Inventory Revamp (owner 2)
        issueRepository.save(newIssue("Stock count mismatch in reports",
                "The report total differs from the warehouse count",
                3, 2, 4, Priority.HIGH, IssueStatus.TO_DO, IssueType.BUG, 2, 7, "reports,database"));
        issueRepository.save(newIssue("Barcode scanner integration",
                "Support USB barcode scanners at the billing counter",
                3, 2, 3, Priority.MEDIUM, IssueStatus.DEVELOPMENT, IssueType.STORY, 2, 5, "hardware"));

        log.info("Demo issues loaded (9 issues)");
    }

    private Issue newIssue(String summary, String description, int projectId, int createdBy, int assigneeId,
            Priority priority, IssueStatus status, IssueType type, int sprint, int storyPoint, String tags) {
        Issue issue = new Issue();
        issue.setSummary(summary);
        issue.setDescription(description);
        issue.setProjectId(projectId);
        issue.setCreatedBy(createdBy);
        issue.setAssigneeId(assigneeId);
        issue.setPriority(priority);
        issue.setStatus(status);
        issue.setType(type);
        issue.setSprint(sprint);
        issue.setStoryPoint(storyPoint);
        issue.setTags(tags);
        return issue;   // createdOn / lastUpdated are filled in by @PrePersist when saved
    }
}
