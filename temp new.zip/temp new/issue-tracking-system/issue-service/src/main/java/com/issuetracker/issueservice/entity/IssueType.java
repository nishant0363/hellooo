package com.issuetracker.issueservice.entity;

/**
 * The kind of work an issue represents. Stored as text in a MySQL ENUM column (see Issue.type).
 * Assumed values. (Named IssueType rather than Type because java.lang.reflect.Type already exists.)
 */
public enum IssueType {
    BUG,
    TASK,
    STORY
}
