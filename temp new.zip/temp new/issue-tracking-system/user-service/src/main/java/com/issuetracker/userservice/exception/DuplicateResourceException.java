package com.issuetracker.userservice.exception;

/**
 * Thrown when a new record would clash with an existing one (email or name already taken).
 * GlobalExceptionHandler turns it into 409 Conflict.
 */
public class DuplicateResourceException extends RuntimeException {

    public DuplicateResourceException(String message) {
        super(message);
    }
}
