package com.issuetracker.userservice.exception;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import feign.FeignException;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Global (centralised) exception handling for every controller in this service.
 *
 * @RestControllerAdvice = @ControllerAdvice + @ResponseBody: the methods below run whenever a controller
 * (or the service it calls) throws the matching exception, and whatever they return is written as JSON.
 * So controllers stay clean - they only handle the "happy path" - and every error has the same shape
 * (ErrorResponse) and the correct HTTP status code.
 *
 * @ResponseStatus on each handler (Milestone 6) is read by springdoc, so Swagger UI lists these error codes
 * (with the ErrorResponse shape) under every endpoint. The status actually sent is the one in the ResponseEntity.
 *
 * Spring always picks the MOST SPECIFIC handler, so the catch-all Exception handler at the bottom
 * only runs for unexpected errors (real bugs, database down ...).
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // ---------- 404 Not Found ----------

    /** An id or name that does not exist, e.g. GET /api/users/999. */
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
        return build(HttpStatus.NOT_FOUND, ex.getMessage(), request, null);
    }

    /** A URL that no controller handles, e.g. GET /api/userz. */
    @ExceptionHandler(NoResourceFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorResponse> handleNoEndpoint(NoResourceFoundException ex, HttpServletRequest request) {
        return build(HttpStatus.NOT_FOUND, "No endpoint found for " + request.getMethod() + " " + request.getRequestURI(),
                request, null);
    }

    // ---------- 409 Conflict ----------

    /** Email or username already taken (checked in the service before saving). */
    @ExceptionHandler(DuplicateResourceException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ResponseEntity<ErrorResponse> handleDuplicate(DuplicateResourceException ex, HttpServletRequest request) {
        return build(HttpStatus.CONFLICT, ex.getMessage(), request, null);
    }

    /**
     * Safety net: the UNIQUE constraint in MySQL rejected a row. This can happen if two sign-ups with the
     * same email arrive at the same moment and both pass the service check before either is saved.
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ResponseEntity<ErrorResponse> handleDataIntegrity(DataIntegrityViolationException ex,
            HttpServletRequest request) {
        log.warn("Database constraint violated: {}", ex.getMostSpecificCause().getMessage());
        return build(HttpStatus.CONFLICT,
                "The request conflicts with existing data (for example a duplicate email or username)", request, null);
    }

    // ---------- 401 Unauthorized ----------

    /** Wrong email or password at login. */
    @ExceptionHandler(InvalidCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ErrorResponse> handleInvalidCredentials(InvalidCredentialsException ex,
            HttpServletRequest request) {
        return build(HttpStatus.UNAUTHORIZED, ex.getMessage(), request, null);
    }

    // ---------- 400 Bad Request ----------

    /** @Valid failed: collect one message per invalid field, e.g. {"email": "Email is required"}. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest request) {
        Map<String, String> fieldErrors = new LinkedHashMap<>();
        for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
            // putIfAbsent: if one field breaks two rules, keep the first message only
            fieldErrors.putIfAbsent(fieldError.getField(), fieldError.getDefaultMessage());
        }
        return build(HttpStatus.BAD_REQUEST, "Validation failed for one or more fields", request, fieldErrors);
    }

    /** The body is not valid JSON, or a value has the wrong type (e.g. role "ADMIN", which is not a Role). */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResponse> handleUnreadableBody(HttpMessageNotReadableException ex,
            HttpServletRequest request) {
        return build(HttpStatus.BAD_REQUEST,
                "Request body is missing or invalid. Check the JSON syntax and the allowed values "
                        + "(role must be PROJECT_OWNER or ASSIGNEE)",
                request, null);
    }

    /** A path variable has the wrong type, e.g. GET /api/users/abc (userId must be a number). */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResponse> handleTypeMismatch(MethodArgumentTypeMismatchException ex,
            HttpServletRequest request) {
        String message = "'" + ex.getValue() + "' is not a valid value for '" + ex.getName() + "'";
        return build(HttpStatus.BAD_REQUEST, message, request, null);
    }

    // ---------- 405 Method Not Allowed ----------

    /** e.g. DELETE /api/users/1 - this service has no delete endpoint for users. */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    public ResponseEntity<ErrorResponse> handleMethodNotAllowed(HttpRequestMethodNotSupportedException ex,
            HttpServletRequest request) {
        return build(HttpStatus.METHOD_NOT_ALLOWED, ex.getMethod() + " is not supported for this URL", request, null);
    }

    // ---------- 503 / 502: another microservice failed (Milestone 5) ----------

    /**
     * A Feign call to another service failed.
     * ex.status() is -1 when no HTTP answer came back at all (service stopped, connection refused, timeout),
     * and 503 when Eureka / the load balancer knows no running instance of that service.
     * Any other status means the other service answered with an error we did not expect -> 502 Bad Gateway.
     */
    @ExceptionHandler(FeignException.class)
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    public ResponseEntity<ErrorResponse> handleOtherServiceFailure(FeignException ex, HttpServletRequest request) {
        log.error("Call to another service failed: {}", ex.getMessage());
        String serviceName = otherServiceName(ex);
        if (ex.status() == -1 || ex.status() == 503) {
            return build(HttpStatus.SERVICE_UNAVAILABLE,
                    serviceName + " is not available right now. Please try again later", request, null);
        }
        return build(HttpStatus.BAD_GATEWAY,
                serviceName + " returned an unexpected error (HTTP " + ex.status() + ")", request, null);
    }

    // ---------- 500 Internal Server Error ----------

    /** Anything unexpected. The details go to the log; the client gets a safe, generic message. */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorResponse> handleUnexpected(Exception ex, HttpServletRequest request) {
        log.error("Unexpected error on {} {}", request.getMethod(), request.getRequestURI(), ex);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong on the server. Please try again later",
                request, null);
    }

    // ---------- helper ----------

    /** Builds the ErrorResponse body and wraps it in a ResponseEntity with the given status code. */
    private ResponseEntity<ErrorResponse> build(HttpStatus status, String message, HttpServletRequest request,
            Map<String, String> fieldErrors) {
        if (status.is4xxClientError()) {
            log.warn("{} {} -> {} {}", request.getMethod(), request.getRequestURI(), status.value(), message);
        }
        ErrorResponse body = new ErrorResponse(
                LocalDateTime.now(),
                status.value(),
                status.getReasonPhrase(),
                message,
                request.getRequestURI(),
                fieldErrors);
        return ResponseEntity.status(status).body(body);
    }

    /** "http://issue-service/api/issues/assignee/3" -> "issue-service" (the service name Feign called). */
    private String otherServiceName(FeignException ex) {
        try {
            String host = URI.create(ex.request().url()).getHost();
            return host != null ? host : "Another service";
        } catch (RuntimeException e) {
            return "Another service";   // no request details available
        }
    }
}
