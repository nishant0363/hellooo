package com.issuetracker.userservice.service;

import java.util.List;

import com.issuetracker.userservice.client.IssueDto;
import com.issuetracker.userservice.dto.LoginRequest;
import com.issuetracker.userservice.dto.SignUpRequest;
import com.issuetracker.userservice.dto.UserResponse;

/**
 * Business operations of the User Service.
 *
 * The controller depends on this INTERFACE, not on the implementation class. That keeps the layers
 * loosely coupled: the implementation can change (or be replaced by a mock in unit tests)
 * without touching the controller.
 */
public interface UserService {

    /** Creates a new user after checking that the email and the username are not taken. */
    UserResponse signUp(SignUpRequest request);

    /** Checks email + password and returns the user if they match. */
    UserResponse login(LoginRequest request);

    List<UserResponse> getAllUsers();

    UserResponse getUserById(Integer userId);

    // ---------- Milestone 5: inter-service communication (asks the Issue Service) ----------

    /** Issues assigned to the user with this id. 404 if the user does not exist. */
    List<IssueDto> getIssuesAssignedToUser(Integer userId);

    /** Issues assigned to the user with this username (not case-sensitive). 404 if no such user. */
    List<IssueDto> getIssuesAssignedToUsername(String username);
}
