package com.issuetracker.userservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.issuetracker.userservice.entity.User;

/**
 * Data access for the user table.
 *
 * We only write the interface. Spring Data JPA creates the implementation at start-up:
 *  - JpaRepository<User, Integer> already gives save(), findById(), findAll(), deleteById(), count() ...
 *  - the extra methods below are "derived queries": Spring reads the method NAME and builds the SQL,
 *    e.g. findByEmail(...)  ->  SELECT * FROM user WHERE email = ?
 */
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    /** Used by login. Optional = "maybe there is no such user", which forces us to handle that case. */
    Optional<User> findByEmail(String email);

    /** Used by the "issues by username" endpoint. Usernames are stored in lower case. */
    Optional<User> findByUsername(String username);

    /** Sign-up checks: is this email / username already taken? (The name may repeat.) */
    boolean existsByEmail(String email);

    boolean existsByUsername(String username);
}
