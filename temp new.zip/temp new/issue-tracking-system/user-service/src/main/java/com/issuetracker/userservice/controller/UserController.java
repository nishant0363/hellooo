package com.issuetracker.userservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.issuetracker.userservice.client.IssueDto;
import com.issuetracker.userservice.dto.LoginRequest;
import com.issuetracker.userservice.dto.LoginResponse;
import com.issuetracker.userservice.dto.SignUpRequest;
import com.issuetracker.userservice.dto.SignUpResponse;
import com.issuetracker.userservice.dto.UserResponse;
import com.issuetracker.userservice.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/**
 * REST endpoints of the User Service (section 7.1 of the case study).
 *
 * @RestController = @Controller + @ResponseBody: every return value is written as JSON.
 * Every method returns a ResponseEntity so we choose the HTTP status code explicitly
 * (200 OK, 201 Created ...). Errors are NOT handled here - the service throws an exception
 * and GlobalExceptionHandler turns it into the right error response.
 *
 * @Operation / @Tag only add descriptions to the Swagger UI page.
 */
@RestController
@RequestMapping("/api/users")
@Tag(name = "User Service", description = "Sign-up, login and user details")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /** GET /api/users -> 200 OK with the list (an empty list if there are no users). */
    @Operation(summary = "Retrieve a list of all users")
    @GetMapping
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    /** POST /api/users -> 201 Created (sign up). 400 if a field is invalid, 409 if email/username is taken. */
    @Operation(summary = "Create a new user (sign up)")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)   // only tells Swagger the success code is 201; ResponseEntity sets it
    public ResponseEntity<SignUpResponse> signUp(@Valid @RequestBody SignUpRequest request) {
        UserResponse createdUser = userService.signUp(request);
        SignUpResponse body = new SignUpResponse(
                "Your account is created successfully",
                "/api/users/login",
                createdUser);
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    /** POST /api/users/login -> 200 OK with the user (including role), or 401 if email/password is wrong. */
    @Operation(summary = "Authenticate a user and log them in")
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        UserResponse user = userService.login(request);
        return ResponseEntity.ok(new LoginResponse("Login successful", user));
    }

    /**
     * GET /api/users/{userId} -> 200 OK, or 404 if there is no such user.
     * The name in @PathVariable("userId") is written out so it works in every IDE/compiler setting.
     */
    @Operation(summary = "Retrieve details of a specific user by user ID")
    @GetMapping("/{userId}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable("userId") Integer userId) {
        return ResponseEntity.ok(userService.getUserById(userId));
    }

    // ---------- Milestone 5: inter-service communication (data comes from the Issue Service) ----------

    /** GET /api/users/{userId}/issues -> 200 OK with the issues assigned to the user, 404 if no such user. */
    @Operation(summary = "Retrieve issues assigned to a specific user by user ID (inter-service: calls Issue Service)")
    @GetMapping("/{userId}/issues")
    public ResponseEntity<List<IssueDto>> getIssuesAssignedToUser(@PathVariable("userId") Integer userId) {
        return ResponseEntity.ok(userService.getIssuesAssignedToUser(userId));
    }

    /** GET /api/users/username/{username}/issues -> same, but the user is found by username, e.g. "rahul". */
    @Operation(summary = "Retrieve issues assigned to a specific user by username (inter-service: calls Issue Service)")
    @GetMapping("/username/{username}/issues")
    public ResponseEntity<List<IssueDto>> getIssuesAssignedToUsername(@PathVariable("username") String username) {
        return ResponseEntity.ok(userService.getIssuesAssignedToUsername(username));
    }
}
