# Issue Tracking System (Spring Boot Microservices + MySQL + React)

A small Jira-like system built as separate Spring Boot microservices. Project Owners create projects and issues and
assign them; Assignees view their issues and update the status.

**Stack:** Java 21, Spring Boot 4.1.1, Spring Data JPA (Hibernate), MySQL 8, springdoc-openapi (Swagger UI) 3.1.1,
Spring Cloud 2025.1.3 (Eureka, Gateway, OpenFeign, LoadBalancer - added from Milestone 4).
**Frontend (Week 4):** React + TypeScript (Vite), React Router, Axios, Bootstrap 5 - see `issue-tracker-ui/README.md`.

## Services

| Service         | Port | Database   | Status           |
|-----------------|------|------------|------------------|
| user-service    | 8081 | user_db    | Milestone 1 done |
| project-service | 8082 | project_db | Milestone 2 done |
| issue-service   | 8083 | issue_db   | Milestone 3 done |
| eureka-server   | 8761 | -          | Milestone 4 done |
| api-gateway     | 8080 | -          | Milestone 7 done |
| issue-tracker-ui (React) | 5173 | -  | Week 4 - talks only to the gateway (8080) |

Each service is its own Maven project and its own Spring Boot application, with its own database
(database-per-service), so each one can be built, tested and started independently.

## Setup (once per machine)

1. **MySQL 8** must be running on `localhost:3306`. No SQL scripts are needed: each service creates its own
   database (`createDatabaseIfNotExist=true`) and its tables (`spring.jpa.hibernate.ddl-auto=update`).
2. **DB credentials:** in every service, copy `src/main/resources/db.properties.example` to `db.properties`
   (same folder) and put in your MySQL username and password. `db.properties` is git-ignored.
3. **Import into Spring Tools / Eclipse:** *File > Import > Maven > Existing Maven Projects*, choose the
   `issue-tracking-system` folder, tick the services, *Finish*. Maven downloads the libraries (first time takes a while).
4. **JDK 21** for every project (*Project > Properties > Java Build Path*).

If a service fails at start-up with `Config data resource 'class path resource [db.properties]' ... does not exist`,
step 2 was skipped for that service.

## Running and testing

**Start order:** MySQL, then `eureka-server`, then `user-service`, `project-service`, `issue-service` and
`api-gateway` (any order). Right-click the `...Application.java` > *Run As > Spring Boot App* (or use the Boot Dashboard).
Give the services ~15 seconds after start-up to register before testing calls between services.

**Eureka dashboard:** http://localhost:8761 - under *Instances currently registered with Eureka* you should see
`API-GATEWAY`, `USER-SERVICE`, `PROJECT-SERVICE` and `ISSUE-SERVICE` (e.g. `user-service:8081`).
Each instance links to its `/actuator/info` page; `/actuator/health` shows whether it (and its database) is up.

**API Gateway:** every endpoint is also reachable through http://localhost:8080 (e.g. http://localhost:8080/api/users).
In each Swagger page, the *Servers* drop-down at the top switches between calling the service directly and calling it
through the gateway. http://localhost:8080/actuator/gateway/routes lists the gateway's routes.

All testing is done in the browser with **Swagger UI** (no Postman needed): open an endpoint, click *Execute*,
and Swagger sends a real HTTP request and shows the status code and JSON response.

- User Service: http://localhost:8081/swagger-ui.html
- Project Service: http://localhost:8082/swagger-ui.html
- Issue Service: http://localhost:8083/swagger-ui.html

Unit tests: right-click `src/test/java` > *Run As > JUnit Test*.

### Demo data (loaded automatically on first start)

| id | Username | Name         | Role          | Email          | Password     |
|----|----------|--------------|---------------|----------------|--------------|
| 1  | priya    | Priya Sharma | PROJECT_OWNER | priya@its.com  | Owner@123    |
| 2  | karan    | Karan Mehta  | PROJECT_OWNER | karan@its.com  | Owner@123    |
| 3  | rahul    | Rahul Verma  | ASSIGNEE      | rahul@its.com  | Assignee@123 |
| 4  | ananya   | Ananya Iyer  | ASSIGNEE      | ananya@its.com | Assignee@123 |

| Project id | Project name       | Owner          | Start      | End        |
|------------|--------------------|----------------|------------|------------|
| 1          | Customer Portal    | 1 Priya Sharma | 2026-09-01 | 2026-12-31 |
| 2          | Mobile Banking App | 1 Priya Sharma | 2026-10-01 | 2027-03-31 |
| 3          | Inventory Revamp   | 2 Karan Mehta  | 2026-08-15 | 2026-11-30 |

The demo users have no profile photo, so the React screens show their initials; a photo appears only for users who give an image URL when signing up.

| Issue id | Summary                              | Project | Created by | Assignee | Priority | Status      | Type  |
|----------|--------------------------------------|---------|------------|----------|----------|-------------|-------|
| 1        | Login page crashes on wrong password | 1       | 1          | 3        | HIGH     | TO_DO       | BUG   |
| 2        | Add password reset by email          | 1       | 1          | 4        | MEDIUM   | DEVELOPMENT | STORY |
| 3        | Profile page loads slowly            | 1       | 1          | 3        | MEDIUM   | TESTING     | BUG   |
| 4        | Show order history to customers      | 1       | 1          | 4        | HIGH     | COMPLETED   | STORY |
| 5        | Add dark mode toggle                 | 1       | 1          | 4        | LOW      | TO_DO       | TASK  |
| 6        | Set up CI pipeline                   | 2       | 1          | 3        | LOW      | COMPLETED   | TASK  |
| 7        | Fingerprint login on Android         | 2       | 1          | 3        | HIGH     | DEVELOPMENT | STORY |
| 8        | Stock count mismatch in reports      | 3       | 2          | 4        | HIGH     | TO_DO       | BUG   |
| 9        | Barcode scanner integration          | 3       | 2          | 3        | MEDIUM   | DEVELOPMENT | STORY |

Demo data is only inserted into an EMPTY table, so restarting a service never duplicates it.
The ids above assume fresh databases.

### Week 4 backend changes (to match the React case study)

| Change | Why |
|--------|-----|
| Issue status is now `TO_DO, DEVELOPMENT, TESTING, COMPLETED`; priority is `LOW, MEDIUM, HIGH` | The React board's four columns and the case study's "Object Value Mapping" |
| `lastUpdated` is a date **and time** (`LocalDateTime`) | The Issue Details screen shows "Last Updated: 10-06-2025 \| 05:30" |
| Description up to 500 characters (column is VARCHAR(500)) | Case study limit |
| `sprint` is a number (1, 2, 3 ...) | Case study: "Sprint: Numbers (1, 2, 3 ...)" |
| Summary 5-100 characters, project name up to 150; only `- / \| .` as special characters | Same rule as the React forms, checked on both sides |
| `PUT /api/issues/{id}` accepts `projectId` (checked with the Project Service) | The Edit Issue screen has a Project drop-down |
| Sign-up: profile image URL is optional but must be an image URL when given; password needs upper case, lower case, number and special character | Case study: "valid image URL", "proper password format" (without a photo the screens show initials) |
| Demo users have profile photos; demo issues fill every board column | So the React screens show real data straight away |
| New unique `username` column; `name` no longer unique | Two users may share a name; the username tells them apart |

**Database reset after pulling these changes.** `ddl-auto=update` adds new tables and columns but never changes or
removes existing ones: it would not change the ENUM values of `status`/`priority`, the type of `sprint`, or remove
the old UNIQUE index on `user.name` (and it cannot add the NOT NULL, UNIQUE `username` column to rows that already
exist). So drop the three databases (they are recreated, with fresh demo data, on the next start; users and
projects you created yourself are lost):

```sql
DROP DATABASE user_db;
DROP DATABASE project_db;
DROP DATABASE issue_db;
```

## API - User Service (port 8081)

| Method | Endpoint             | Description                           | Success | Errors             |
|--------|----------------------|---------------------------------------|---------|--------------------|
| GET    | /api/users           | Retrieve a list of all users          | 200     | -                  |
| POST   | /api/users           | Create a new user (sign up)           | 201     | 400, 409           |
| POST   | /api/users/login     | Authenticate a user (email+password)  | 200     | 400, 401           |
| GET    | /api/users/{userId}  | Retrieve a user by id                 | 200     | 400, 404           |
| GET    | /api/users/{userId}/issues | Issues assigned to a user (calls Issue Service, Feign) | 200 | 400, 404, 503 |
| GET    | /api/users/username/{username}/issues | Same, user found by username (calls Issue Service, Feign) | 200 | 404, 503 |

## API - Project Service (port 8082)

| Method | Endpoint                      | Description                              | Success | Errors        |
|--------|-------------------------------|------------------------------------------|---------|---------------|
| GET    | /api/projects                 | Retrieve a list of all projects          | 200     | -             |
| POST   | /api/projects                 | Create a new project (owner checked with User Service) | 201 | 400, 409, 503 |
| GET    | /api/projects/{projectId}     | Retrieve a project by id                 | 200     | 400, 404      |
| PUT    | /api/projects/{projectId}     | Update a project                         | 200     | 400, 404, 409, 503 |
| DELETE | /api/projects/{projectId}     | Delete a project (refused while it has issues) | 200 | 400, 404, 409, 503 |
| GET    | /api/projects/owner/{ownerId} | Retrieve projects owned by a user        | 200     | 400           |
| GET    | /api/projects/{projectId}/issues | Issues of a project (calls Issue Service, Feign) | 200 | 400, 404, 503 |
| GET    | /api/projects/projectName/{projectName}/issues | Same, project found by name (calls Issue Service, Feign) | 200 | 404, 503 |

## API - Issue Service (port 8083)

| Method | Endpoint                             | Description                                         | Success | Errors   |
|--------|--------------------------------------|-----------------------------------------------------|---------|----------|
| GET    | /api/issues                          | Retrieve a list of all issues                       | 200     | -        |
| POST   | /api/issues                          | Create a new issue (project/users checked, Feign)   | 201     | 400, 503 |
| GET    | /api/issues/{id}                     | Retrieve an issue by id                             | 200     | 400, 404 |
| PUT    | /api/issues/{id}                     | Update an issue (only the fields sent are changed)  | 200     | 400, 404, 503 |
| DELETE | /api/issues/{id}                     | Delete an issue (added - see assumptions)           | 200     | 400, 404 |
| GET    | /api/issues/project/{projectId}      | Issues of a project (inter-service)                 | 200     | 400      |
| GET    | /api/issues/owner/{ownerId}          | Issues created by a user (inter-service)            | 200     | 400      |
| GET    | /api/issues/assignee/{assigneeId}    | Issues assigned to a user (inter-service)           | 200     | 400      |

## API Gateway and client-side load balancing (Milestone 7)

```
Client (Swagger / browser / React)
   |  every request goes to http://localhost:8080
   v
API Gateway  --/api/users/**----> lb://user-service    (8081)
             --/api/projects/**-> lb://project-service (8082)
             --/api/issues/**---> lb://issue-service   (8083, 8084 ...)
```

- Routes are defined in `api-gateway/.../config/GatewayConfig.java`. `lb://issue-service` means: ask Eureka for all
  running instances of issue-service and let Spring Cloud LoadBalancer pick one (round robin).
- This is **client-side load balancing**: the caller (the gateway, or a Feign / `@LoadBalanced` client inside a
  service) chooses the instance itself, instead of a separate load-balancer server sitting in front.
- The gateway runs on Spring WebFlux (Netty), not Spring MVC, so its project must not contain `spring-boot-starter-webmvc`.
- CORS is set once at the gateway so the Swagger pages (ports 8081-8083) and the React app can call port 8080: the Vite dev server (5173), the production build served by `npm run preview` (4173) and a Create React App server (3000).
- If no instance of a service is running, the gateway answers 503 Service Unavailable.

**Load-balancing demo:** start a second Issue Service on port 8084 (*Run Configurations* > duplicate
`IssueServiceApplication` > *Arguments* > Program arguments `--server.port=8084`). Eureka then lists two
ISSUE-SERVICE instances. Call http://localhost:8080/api/issues a few times: the log line
`GET /api/issues handled by this instance` appears in the two consoles in turn.

## Service discovery and inter-service communication (Milestones 4 and 5)

Every service registers with **Eureka** under its `spring.application.name`. Services never call each other by
host and port: they use the service NAME (`http://user-service/...`), and **Spring Cloud LoadBalancer** asks Eureka
for a running instance and picks one (client-side load balancing).

| Caller          | Calls           | How          | Why                                                                |
|-----------------|-----------------|--------------|--------------------------------------------------------------------|
| user-service    | issue-service   | Feign        | issues assigned to a user (by id or by name)                       |
| project-service | issue-service   | Feign        | issues of a project (by id or by name); refuse deleting a project that still has issues |
| project-service | user-service    | RestTemplate | check the project owner exists and is a PROJECT_OWNER              |
| issue-service   | project-service | Feign        | check the issue's project exists                                   |
| issue-service   | user-service    | Feign        | check the creator is a PROJECT_OWNER and the assignee an ASSIGNEE  |

- **Feign:** we write an interface with `@FeignClient(name = "issue-service")` and `@GetMapping` methods;
  Spring Cloud generates the HTTP code.
- **RestTemplate:** we build the URL and call `getForObject(...)` ourselves; the bean is marked `@LoadBalanced`
  so the service name in the URL is resolved through Eureka.
- If a service that is needed is down, the caller answers **503 Service Unavailable** with the service's name
  and saves nothing. A bad id inside a request body (unknown project, wrong role) is a **400**.

**Milestone 6 - ResponseEntity, status codes and Swagger:** every endpoint returns a `ResponseEntity` with an explicit
status and, for writes, a descriptive message. Each exception handler carries `@ResponseStatus`, so Swagger lists the
possible error codes (with the error JSON shape) under every endpoint, and create endpoints are documented as 201.

Convention in every service: reads (GET) return the data; writes return a confirmation message
(plus the saved object for POST/PUT), e.g. `{"message": "Project 3 deleted successfully"}`.

## Errors

Every error has the same JSON shape:

```json
{
  "timestamp": "2026-10-01T10:15:30",
  "status": 404,
  "error": "Not Found",
  "message": "User not found with id 99",
  "path": "/api/users/99"
}
```

Validation errors (400) also contain `fieldErrors`, e.g. `{"email": "Email must be a valid email address"}`.

## Assumptions

The reference spreadsheet (sample endpoints and DB) was not available, so these assumptions were made.

**General**
- No Comment Service: it appears in the service list, but not in the architecture diagram, the DB design or the
  milestones, and the guidelines describe in-issue commenting as a future add-on.
- Testing is done with Swagger UI instead of Postman (Swagger is required by Milestone 6 anyway).
- No token-based security (JWT). "Authentication" = passwords stored as BCrypt hashes and checked at login.
  Securing every request (e.g. JWT checked at the API Gateway) is future scope.
- Role-based dashboards and the redirect after login are frontend concerns; the login response includes the
  user's role so a frontend can decide which dashboard to open.

**Users**
- Role is `PROJECT_OWNER` or `ASSIGNEE`, stored as a TINYINT (0/1) to match the DB design.
- Login uses email + password (the login field list in the case study repeats the sign-up fields).
- Email is unique and stored in lower case, so login is not case-sensitive.
- **Username** (added in Week 4) is the unique handle used by `GET /api/users/username/{username}/issues`:
  3-30 letters, numbers, dot, underscore or hyphen, stored in lower case (so `Priya` and `priya` are the same).
  The **name** is only for display and does not need to be unique - two people called "Nishant" can both sign up.
  (In Week 3 the name itself acted as the username and had to be unique.)
- Password: 8-64 characters with at least one upper-case letter, one lower-case letter, one number and one special
  character (Week 4 "proper password format"). Stored only as a BCrypt hash, never returned in any response.
- Profile image is an optional URL (the column is VARCHAR, not a file). When given it must start with `http://` or
  `https://` and end in `.png`, `.jpg`, `.jpeg`, `.gif`, `.webp` or `.svg` (Week 4 "valid image URL"); an empty value
  is stored as NULL and the React screens show the user's initials instead.
- Unknown email and wrong password give the same 401 message, so nobody can find out which emails are registered.
- Sign-up returns "Your account is created successfully" plus the login URL (the "hyperlink to login").

**Projects**
- Project name is required and unique (not case-sensitive), because the case study looks projects up by name.
  At most 150 characters; letters, numbers, spaces and only `- / | .` as special characters (Week 4).
- Start date is required; end date is optional, but if given it must not be before the start date.
  Dates use the format `yyyy-MM-dd`. Start dates in the past are allowed (a project may already be running).
- PUT replaces all editable fields (name, owner, start date, end date), with the same rules as create.
- `GET /api/projects/owner/{ownerId}` returns an empty list when the user owns no projects.
- The owner must exist and be a PROJECT_OWNER (checked with the User Service via RestTemplate). On update the
  check only runs when the owner changes. The React app always sends the logged-in owner, so owners create projects
  only for themselves; the API alone cannot enforce that without login tokens (JWT).
- A project that still has issues cannot be deleted (409): there are no foreign keys across databases, so this
  check stops issues pointing at a deleted project.

**Issues**
- Enum values (from the Week 4 "Object Value Mapping"): priority `LOW, MEDIUM, HIGH`;
  status `TO_DO, DEVELOPMENT, TESTING, COMPLETED`; type `BUG, TASK, STORY`. Stored as text in MySQL ENUM columns.
- Required on create: summary, projectId, assigneeId, createdBy, priority, type.
  Optional: description, status (default `TO_DO`), sprint (a positive number), storyPoint (0-100, default 0), tags.
- Summary: 5-100 characters, letters, numbers, spaces and only `- / | .`. Description: at most 500 characters.
  Screen-only rules (sprint and story points required, story points must be prime) are checked by the React form.
- Tags are a comma-separated text, tidied on save: `" Backend, login,,backend "` is stored as `"backend,login"`.
- `createdOn` (a date) and `lastUpdated` (a date and time) are set by the server (JPA `@PrePersist` / `@PreUpdate`),
  never taken from the client.
- Comments are not stored (no Comment Service and no comments column in the DB design).
- PUT is a partial update: only the fields sent are changed, so an assignee can send just `{"status": "DEVELOPMENT"}`.
  `createdBy` cannot be changed; `projectId` can (Week 4), and the new project must exist.
  An empty update (`{}`) is rejected with 400. Send `""` to clear description or tags.
- Any status can move to any other status (no workflow rules).
- The "owner" of an issue (`/api/issues/owner/{ownerId}`) is the user who created it (`created_by`).
- `DELETE /api/issues/{id}` was added: the objective mentions deleting issues, but the endpoint table has no delete.
- The `/project`, `/owner` and `/assignee` look-ups return an empty list when nothing matches.
- Before saving, the project must exist, the creator (`createdBy`) must be a PROJECT_OWNER and the assignee an
  ASSIGNEE - checked with the Project and User services (Feign). On update, the assignee is only checked when it
  changes. Any PROJECT_OWNER may create issues in any project.

**Service discovery / communication**
- `GET /api/users/{userId}/issues` and the project equivalents first check the user/project exists locally
  (404 if not) and only then ask the Issue Service, so an unknown id is a clear 404 rather than an empty list.
- A reference to another service's data inside a request body (unknown project, user with the wrong role) is a
  400 Bad Request, because the URL itself is fine - it is the body that is wrong.
- Methods that call another service are not wrapped in a database transaction, so no DB connection is held
  while waiting for the network.
- Eureka self-preservation is switched off and heartbeat/refresh timings are shortened, because the defaults are
  tuned for production and make a laptop demo slow to react.

## Week 5 - AWS deployment

The same code runs on the laptop and on AWS; only configuration changes.

- **Spring profile `aws`** (`src/main/resources/application-aws.properties` in user-service, project-service,
  issue-service and api-gateway). Activated with `SPRING_PROFILES_ACTIVE=aws`. It reads everything that differs on
  AWS from environment variables: `EUREKA_URL`, `DB_HOST`, `DB_USERNAME`, `DB_PASSWORD` (services) and
  `FRONTEND_ORIGIN` (gateway). Each instance registers in Eureka with its **private IP** (`prefer-ip-address`)
  instead of `localhost`, with an instance id that includes the IP, so two copies of a service can run side by side.
  The connection to RDS is encrypted (`sslMode=REQUIRED`). Without the profile nothing changes locally.
- **CORS** origins are now the property `app.cors.allowed-origins` (localhost addresses by default; the S3 website
  address on AWS), read by `GatewayConfig.corsWebFilter`.
- `spring.config.import=optional:classpath:db.properties` - the services also start where no local
  `db.properties` exists (AWS supplies the credentials).
- **Dockerfile** in each application folder (Amazon Corretto 21, non-root user) for ECS Fargate.
- **`aws/` folder**: EC2 first-boot script, settings template, RDS SQL scripts (one MySQL user per service), the
  S3-triggered profile-photo Lambda, and helper scripts for copying JARs and pushing images. See `aws/README.md`.

| Environment variable | Used by | Example |
|---|---|---|
| `SPRING_PROFILES_ACTIVE` | all except eureka-server | `aws` |
| `EUREKA_URL` | gateway + 3 services | `http://10.0.3.25:8761/eureka/` (EC2), `http://eureka.ic.local:8761/eureka/` (ECS) |
| `DB_HOST` | 3 services | the RDS endpoint |
| `DB_USERNAME` / `DB_PASSWORD` | 3 services | `user_svc`, `project_svc`, `issue_svc` + their passwords |
| `FRONTEND_ORIGIN` | api-gateway | `http://ic-frontend-<you>.s3-website-us-east-1.amazonaws.com` |
