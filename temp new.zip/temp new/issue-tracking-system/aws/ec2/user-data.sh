#!/bin/bash
# =====================================================================================================
# EC2 user data for ONE Issue Tracker application server (Milestone 1).
# Runs once, as root, on first boot. Change SERVICE (and nothing else) for each of the five instances:
#   eureka-server | api-gateway | user-service | project-service | issue-service
# It installs Java 21, the MySQL client and the CloudWatch agent, prepares folders, the systemd service
# and the CloudWatch agent configuration. The JAR and the settings file are added later (Part 6.7).
# =====================================================================================================
SERVICE=user-service
JAR=${SERVICE}-1.0.0.jar

# 1. Software
dnf install -y java-21-amazon-corretto-headless mariadb105 amazon-cloudwatch-agent

# 2. Folders: the JAR, the settings (secret, root only) and the log file
mkdir -p /home/ec2-user/app /etc/issue-tracker /var/log/issue-tracker
chown ec2-user:ec2-user /home/ec2-user/app
touch /etc/issue-tracker/app.env
chmod 600 /etc/issue-tracker/app.env

# 3. systemd service: start at boot, restart on failure, run as ec2-user, log to a file
cat > /etc/systemd/system/issue-tracker.service <<EOF
[Unit]
Description=Issue Tracker - ${SERVICE}
After=network-online.target
Wants=network-online.target

[Service]
User=ec2-user
WorkingDirectory=/home/ec2-user/app
EnvironmentFile=/etc/issue-tracker/app.env
ExecStart=/usr/bin/java -Xms128m -Xmx384m -jar /home/ec2-user/app/${JAR}
SuccessExitStatus=143
Restart=on-failure
RestartSec=10
StandardOutput=append:/var/log/issue-tracker/app.log
StandardError=append:/var/log/issue-tracker/app.log

[Install]
WantedBy=multi-user.target
EOF

# 4. CloudWatch agent: ship the log file + memory and disk usage (the \$ keeps ${aws:...} for the agent)
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json <<EOF
{
  "agent": { "run_as_user": "root" },
  "logs": { "logs_collected": { "files": { "collect_list": [
    { "file_path": "/var/log/issue-tracker/app.log",
      "log_group_name": "/issue-tracker/m1/${SERVICE}",
      "log_stream_name": "{instance_id}",
      "retention_in_days": 14 } ] } } },
  "metrics": {
    "namespace": "IssueTracker/EC2",
    "append_dimensions": { "InstanceId": "\${aws:InstanceId}" },
    "metrics_collected": {
      "mem":  { "measurement": ["mem_used_percent"] },
      "disk": { "measurement": ["used_percent"], "resources": ["/"] } } }
}
EOF
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s \
  -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json

# 5. Register the service (it is started by hand once the JAR and app.env are in place)
systemctl daemon-reload
systemctl enable issue-tracker
