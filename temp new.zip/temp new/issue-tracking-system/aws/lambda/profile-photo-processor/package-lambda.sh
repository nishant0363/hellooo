#!/bin/bash
# =====================================================================================================
# package-lambda.sh - Milestone 1: build photo-lambda.zip for the profile-photo Lambda.
# Run on an Amazon Linux EC2 that has internet access (ic-gateway), in a folder containing
# lambda_function.py, requirements.txt and this script:   bash package-lambda.sh
# The zip holds, at its top level: our code + PyMySQL (not part of the Lambda runtime) + the Amazon RDS
# certificate bundle used to verify the TLS connection to MySQL.
# =====================================================================================================
set -euo pipefail

sudo dnf install -y python3-pip zip > /dev/null
rm -rf build photo-lambda.zip
mkdir build
cp lambda_function.py build/
pip3 install --quiet --target build -r requirements.txt
curl -sS -o build/global-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
(cd build && zip -qr ../photo-lambda.zip .)
echo "Created $(pwd)/photo-lambda.zip - copy it to your laptop and upload it in the Lambda console."
