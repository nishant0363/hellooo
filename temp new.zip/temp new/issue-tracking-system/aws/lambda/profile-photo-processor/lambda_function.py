"""
InfinityCastle - profile photo processor (AWS Lambda, Python 3.12).

Trigger : S3 "All object create events" on the photos bucket, prefix "profile-photos/".
Input   : uploaded files named profile-photos/<username>.<jpg|jpeg|png|gif|webp>
Work    : 1. check the key, the extension and the size (max 2 MB)
          2. ask S3 for the object's Content-Type (must be image/...)
          3. save the photo's public URL as that user's profile in RDS (user_db.user.profile)
Output  : a status per file; every decision is logged to CloudWatch Logs.

Environment variables: DB_HOST (RDS endpoint), DB_NAME (user_db), DB_USER (photo_lambda), DB_PASSWORD.
global-bundle.pem (the Amazon RDS certificates) is packaged next to this file, for TLS to MySQL.
"""
import logging
import os
import urllib.parse

import boto3
import pymysql
from pymysql.constants import CLIENT

logger = logging.getLogger()
logger.setLevel(logging.INFO)

PREFIX = "profile-photos/"
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "gif", "webp"}
MAX_SIZE_BYTES = 2 * 1024 * 1024
CA_BUNDLE = os.path.join(os.path.dirname(__file__), "global-bundle.pem")

# Created once per execution environment and reused by warm invocations
s3 = boto3.client("s3")


def lambda_handler(event, context):
    """Entry point. One S3 event may contain several records."""
    results = []
    for record in event.get("Records", []):
        bucket = record["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])   # keys arrive URL-encoded
        size = record["s3"]["object"].get("size", 0)
        results.append(process_photo(bucket, key, size))
    return {"results": results}


def process_photo(bucket, key, size):
    """Validates one upload and stores its URL. Returns a short status (also useful in console tests)."""
    if not key.startswith(PREFIX):
        return skip(key, "not under " + PREFIX)
    file_name = key[len(PREFIX):]
    if "/" in file_name or "." not in file_name:
        return skip(key, "expected profile-photos/<username>.<extension>")

    username, extension = file_name.rsplit(".", 1)
    username = username.lower()            # usernames are stored in lower case
    extension = extension.lower()
    if extension not in ALLOWED_EXTENSIONS:
        return skip(key, "." + extension + " is not an accepted image type")
    if size > MAX_SIZE_BYTES:
        return skip(key, "file is larger than 2 MB")

    # Read only the object's metadata (no download). Reached through the S3 gateway endpoint.
    content_type = s3.head_object(Bucket=bucket, Key=key).get("ContentType", "")
    if not content_type.startswith("image/"):
        return skip(key, "Content-Type is " + content_type)

    region = os.environ["AWS_REGION"]      # set by Lambda itself
    photo_url = "https://%s.s3.%s.amazonaws.com/%s" % (bucket, region, urllib.parse.quote(key))

    connection = pymysql.connect(
        host=os.environ["DB_HOST"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ.get("DB_NAME", "user_db"),
        ssl={"ca": CA_BUNDLE},             # encrypted connection, RDS certificate verified
        client_flag=CLIENT.FOUND_ROWS,     # rowcount = matched rows, even when the URL is unchanged
        connect_timeout=5,
    )
    try:
        with connection.cursor() as cursor:
            matched = cursor.execute(
                "UPDATE `user` SET profile = %s WHERE username = %s", (photo_url, username))
        connection.commit()
    finally:
        connection.close()

    if matched == 0:
        return skip(key, "no user with username '" + username + "'")
    logger.info("Profile photo of %s set to %s", username, photo_url)
    return {"key": key, "status": "UPDATED", "username": username, "url": photo_url}


def skip(key, reason):
    """Logs why an upload was ignored. The object stays in S3 and the database is not touched."""
    logger.warning("Skipped %s: %s", key, reason)
    return {"key": key, "status": "SKIPPED", "reason": reason}
