# AWS deployment files (Week 5)

Scripts and templates used to deploy InfinityCastle - Issue Tracker on AWS. The full, step-by-step runbook
(console steps, checkpoints, troubleshooting) is the guide `InfinityCastle-AWS-Deployment-Guide.pdf`.
Values in angle brackets (`<RDS-ENDPOINT>`) and `CHANGE_ME` passwords are placeholders: put the real values
only on the servers or in the AWS console, never in Git.

| File | Used in | Purpose |
|------|---------|---------|
| `ec2/user-data.sh` | Milestone 1, EC2 launch | First-boot script: Java 21, MySQL client, CloudWatch agent, systemd service. Set `SERVICE=` per instance |
| `ec2/app.env.example` | Milestone 1 | Template of `/etc/issue-tracker/app.env` (environment variables of one application) |
| `rds/01-schemas-and-users.sql` | Milestone 1 | Creates `user_db`, `project_db`, `issue_db` and one MySQL user per service |
| `rds/02-lambda-user.sql` | Milestone 1 | Lambda user that may only read `username` and update `profile` |
| `lambda/profile-photo-processor/` | Milestone 1 | The S3-triggered Lambda (Python 3.12) + `package-lambda.sh` to build its zip |
| `scripts/deploy-jar.ps1` | Milestone 1 | Laptop: copy one JAR to its EC2 and restart the service |
| `scripts/build-frontend.ps1` | Milestones 1 + 2 | Laptop: build the React app with the AWS API address (`-ApiUrl`) for the S3 bucket |
| `scripts/copy-to-builder.ps1` | Milestone 2 | Laptop: copy the five Dockerfiles + JARs to the builder EC2 |
| `scripts/build-and-push.sh` | Milestone 2 | Builder: build the five images and push them to ECR |

The applications themselves read their AWS settings from environment variables through the Spring profile
`aws` (`src/main/resources/application-aws.properties` in each service and the gateway). Each application
also has a `Dockerfile` for Milestone 2.
