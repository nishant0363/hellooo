<#
  build-frontend.ps1 - build the React app for AWS (the files you upload to the S3 website bucket).

  Run in PowerShell from the issue-tracking-system folder:
      Milestone 1:  .\aws\scripts\build-frontend.ps1 -ApiUrl http://<GATEWAY-ELASTIC-IP>:8080/api
      Milestone 2:  .\aws\scripts\build-frontend.ps1 -ApiUrl http://<ALB-DNS-NAME>/api
  Result: issue-tracker-ui\dist  ->  upload its CONTENTS (index.html, favicon.svg, assets folder) to the bucket.

  How it works: Vite bakes VITE_API_BASE_URL into the JavaScript at build time. A variable that already exists
  in the environment wins over the .env files, so the script sets it only for this build and removes it again.
  Local "npm run dev" keeps using http://localhost:8080/api.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$ApiUrl
)

if ($ApiUrl -notmatch '^https?://.+/api$') { Write-Error "ApiUrl must look like http://<host>[:port]/api"; exit 1 }

Push-Location .\issue-tracker-ui
try {
    $env:VITE_API_BASE_URL = $ApiUrl
    Write-Host "Building the React app with VITE_API_BASE_URL=$ApiUrl ..."
    npm run build
    if ($LASTEXITCODE -ne 0) { Write-Error "npm run build failed"; exit 1 }
    Write-Host "Done. Upload the contents of issue-tracker-ui\dist to the S3 bucket."
}
finally {
    Remove-Item Env:VITE_API_BASE_URL -ErrorAction SilentlyContinue
    Pop-Location
}
