<#
  deploy-jar.ps1 - Milestone 1: copy ONE application's JAR to its EC2 and (re)start it.

  Run in PowerShell from the issue-tracking-system folder, after "mvn clean package" for that application:
      .\aws\scripts\deploy-jar.ps1 -App user-service -Server 3.91.24.180
  If Windows blocks scripts, run it like this instead:
      powershell -ExecutionPolicy Bypass -File .\aws\scripts\deploy-jar.ps1 -App user-service -Server 3.91.24.180

  The server must already have /etc/issue-tracker/app.env filled in (Part 6.7 of the guide).
  The key defaults to C:\Users\<you>\aws-keys\ic-key.pem - pass -Key to use another path.
#>
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("eureka-server", "api-gateway", "user-service", "project-service", "issue-service")]
    [string]$App,

    [Parameter(Mandatory = $true)]
    [string]$Server,                                   # public IP (or Elastic IP) of the EC2

    [string]$Key = "$env:USERPROFILE\aws-keys\ic-key.pem"
)

$jar = ".\$App\target\$App-1.0.0.jar"
if (-not (Test-Path $jar)) { Write-Error "Not found: $jar - run 'mvn clean package' for $App first."; exit 1 }
if (-not (Test-Path $Key)) { Write-Error "Key not found: $Key - pass -Key <path to ic-key.pem>."; exit 1 }

Write-Host "1/2 Copying $jar to $Server ..."
scp -i $Key $jar "ec2-user@${Server}:/home/ec2-user/app/"
if ($LASTEXITCODE -ne 0) { Write-Error "scp failed (security group, IP or key?)"; exit 1 }

Write-Host "2/2 Restarting the service on $Server (first start of Spring Boot takes about 30-60 s) ..."
ssh -i $Key "ec2-user@$Server" "sudo systemctl restart issue-tracker && sleep 3 && systemctl --no-pager status issue-tracker | head -n 5"
Write-Host "Follow the log with:  ssh -i $Key ec2-user@$Server 'tail -f /var/log/issue-tracker/app.log'"
