#!/bin/bash
# =====================================================================================================
# build-and-push.sh - Milestone 2, run on ic-builder (Docker installed, IAM role ic-builder-role).
# Builds the five images from ~/build/<app> and pushes them to the ECR repositories issue-tracker/<app>.
# The repositories must exist (ECR console). No access keys are needed: the instance role is used.
#   Usage:  bash build-and-push.sh            (version tag 1.0.0)
#           bash build-and-push.sh 1.0.1      (another version tag)
# =====================================================================================================
set -euo pipefail                      # stop at the first error, unknown variable or failed pipe

VERSION=${1:-1.0.0}
REGION=${AWS_REGION:-us-east-1}
APPS="eureka-server api-gateway user-service project-service issue-service"
ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
REGISTRY=$ACCOUNT.dkr.ecr.$REGION.amazonaws.com

cd ~/build
for app in $APPS; do
  echo "== Building issue-tracker/$app:$VERSION"
  docker build -t "issue-tracker/$app:$VERSION" "./$app"
done

echo "== Logging Docker in to $REGISTRY (token valid 12 hours)"
aws ecr get-login-password --region "$REGION" | docker login --username AWS --password-stdin "$REGISTRY"

for app in $APPS; do
  echo "== Pushing $app"
  docker tag "issue-tracker/$app:$VERSION" "$REGISTRY/issue-tracker/$app:$VERSION"
  docker push "$REGISTRY/issue-tracker/$app:$VERSION"
done

echo
echo "Image URIs for the ECS task definitions:"
for app in $APPS; do echo "  $REGISTRY/issue-tracker/$app:$VERSION"; done
