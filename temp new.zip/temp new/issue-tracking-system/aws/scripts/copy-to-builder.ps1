<#
  copy-to-builder.ps1 - Milestone 2: copy the five Dockerfiles and JARs to the builder EC2 (ic-builder).

  Run in PowerShell from the issue-tracking-system folder, after "mvn clean package" for all five applications:
      .\aws\scripts\copy-to-builder.ps1 -Server <BUILDER-PUBLIC-IP>
  Result on the builder:  ~/build/<app>/Dockerfile  and  ~/build/<app>/target/<app>-1.0.0.jar
  Then on the builder:    bash build-and-push.sh
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$Server,
    [string]$Key = "$env:USERPROFILE\aws-keys\ic-key.pem"
)

$apps = "eureka-server", "api-gateway", "user-service", "project-service", "issue-service"

ssh -i $Key "ec2-user@$Server" "mkdir -p ~/build/{eureka-server,api-gateway,user-service,project-service,issue-service}/target"
if ($LASTEXITCODE -ne 0) { Write-Error "ssh failed (security group, IP or key?)"; exit 1 }

foreach ($app in $apps) {
    $jar = ".\$app\target\$app-1.0.0.jar"
    if (-not (Test-Path $jar)) { Write-Error "Not found: $jar - run 'mvn clean package' first."; exit 1 }
    Write-Host "Copying $app ..."
    scp -i $Key ".\$app\Dockerfile" "ec2-user@${Server}:~/build/$app/"
    scp -i $Key $jar "ec2-user@${Server}:~/build/$app/target/"
}
scp -i $Key ".\aws\scripts\build-and-push.sh" "ec2-user@${Server}:~/build-and-push.sh"
Write-Host "Done. On the builder run:  bash build-and-push.sh"
