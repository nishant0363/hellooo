-- =====================================================================================
-- 02-lambda-user.sql - run AFTER user-service has started once (its tables must exist):
--   mysql -h <RDS-ENDPOINT> -u admin -p --ssl < 02-lambda-user.sql
-- Column-level grant: the Lambda may read user names and change the profile column - nothing else.
-- =====================================================================================
CREATE USER IF NOT EXISTS 'photo_lambda'@'10.0.%' IDENTIFIED BY 'CHANGE_ME_Lambda#2026';
GRANT SELECT (username), UPDATE (profile) ON user_db.`user` TO 'photo_lambda'@'10.0.%';
SHOW GRANTS FOR 'photo_lambda'@'10.0.%';
