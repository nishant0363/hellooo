-- =====================================================================================
-- 01-schemas-and-users.sql - run ONCE as the RDS master user, from ic-gateway:
--   mysql -h <RDS-ENDPOINT> -u admin -p --ssl < 01-schemas-and-users.sql
-- One schema per microservice and one MySQL user per service that can use only its own schema.
-- '10.0.%' = connections from inside ic-vpc only. Replace the three passwords before running.
-- =====================================================================================
CREATE DATABASE IF NOT EXISTS user_db;
CREATE DATABASE IF NOT EXISTS project_db;
CREATE DATABASE IF NOT EXISTS issue_db;

CREATE USER IF NOT EXISTS 'user_svc'@'10.0.%'    IDENTIFIED BY 'CHANGE_ME_User#2026';
CREATE USER IF NOT EXISTS 'project_svc'@'10.0.%' IDENTIFIED BY 'CHANGE_ME_Project#2026';
CREATE USER IF NOT EXISTS 'issue_svc'@'10.0.%'   IDENTIFIED BY 'CHANGE_ME_Issue#2026';

-- Hibernate (ddl-auto=update) needs CREATE/ALTER/INDEX/REFERENCES to build its tables. No DROP, no other schema.
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES ON user_db.*    TO 'user_svc'@'10.0.%';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES ON project_db.* TO 'project_svc'@'10.0.%';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES ON issue_db.*   TO 'issue_svc'@'10.0.%';

SHOW DATABASES;
SELECT user, host FROM mysql.user WHERE user LIKE '%svc';
